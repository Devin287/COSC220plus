#include "Employee.h"
#include <iostream>

/*************************************************************************/
                         /* Employee Class */
//Employee constructor
Employee::Employee(std::string empName, double empRate)
{
  name = empName;
  payRate = empRate;
}

//returns the amount the employee should be paid
double Employee::pay()
{
  return 0;
}

//prints to stdout the employee information
void Employee::print()
{
  std::cout << "Name: " << name << " " << payRate <<"\n";
}


/*************************************************************************/
          /* Hourly Class derived from employee Implementation */
//Hourly constructor
Hourly::Hourly(std::string empName, double empRate):Employee(empName,empRate)
{
  hoursWorked = 0;
}

//Adds hours to Hourly objects
void Hourly::addHours(int x)
{
  hoursWorked = x;
}

//Pays Hourly Objects
double Hourly::pay()
{
  double total = hoursWorked * payRate;
  addHours(0.0);
  return total;
}

//Prints hourly objects
void Hourly::print()
{
  std::cout << "Name: " << name << " " << payRate << " " << hoursWorked << "\n";
}


/*************************************************************************/
        /* Executive Class derived from employee Implementation */

//Executive constructor
Executive::Executive(std::string empName, double empRate):Employee(empName,empRate)
{

}

//Set the bonus pay for executive objects
void Executive::setBonusPay(double x)
{
  bonusPay = x;
}

//Pays the executive objects
double Executive::pay()
{
  double totalPay = Employee::pay() + bonusPay;
  setBonusPay(0.0);
  return totalPay;
}

//Prints the executive objects
void Executive::print()
{
  Employee::print();
  std::cout << "Bonus pay is: " << bonusPay << "\n";
}

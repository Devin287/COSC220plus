#ifndef EMPLOYEE_H
#define EMPLOYEE_H
#include<iostream>

class Employee
{
protected:
  double payRate;
  std::string name;

public:
  //non-default constructor
  Employee(std::string empName, double empRate);
  //returns the amount the employee should be paid
  virtual double pay();
  //prints to stdout the employee information
  virtual void print();
};

class Hourly : public Employee
{
  public:
    //Prototypes Methods and variables
    int hoursWorked;

    Hourly(std::string empName, double empRate);
    void addHours(int);
    double pay()override;
    void print()override;
};

class Executive : public Employee
{
public:
  //Prototypes Methods and variables
  Executive(std::string empName, double empRate);
  double pay()override;
  void print()override;
  void setBonusPay(double);

  private:
    double bonusPay;
};
#endif

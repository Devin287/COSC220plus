#include "Employee.h"
#include <iostream>

int main()
{

  std::cout << "\nTesting Base Employee..\n";
  Employee emp("Devin", 10.0);
  emp.print();

  std::cout << "\nTesting Derived Hourly..\n";
  Hourly hObj("Dr.Dobb",9.0);
  hObj.print();

  hObj.addHours(5);
  hObj.print();

  std::cout << "\nAmount payed is: " << hObj.pay() << "\n";
  hObj.print();

  std::cout << "\nTesting Derived Executive..\n";
  Executive ceo("John", 20.0);
  ceo.setBonusPay(9000.0);
  ceo.print();
  ceo.pay();
  ceo.print();


  std::cout << "\nTesting array of objects..\n";
  Employee *employees[6];

  Employee dev("Dev", 19.0);
  employees[0] = &dev;

  Employee eve("Eve", 19.0);
  employees[1] = &eve;

  Hourly hr("Joe", 11.0);
  hr.addHours(15);
  employees[2] = &hr;

  Hourly sonic("Sonic", 12.0);
  sonic.addHours(20);
  employees[3] = &sonic;

  Executive master("Master Chief", 200.0);
  master.setBonusPay(90000.0);
  employees[4] = &master;

  Executive collec("Collection", 40.0);
  collec.setBonusPay(900000.0);
  employees[5] = &collec;

  employees[0]->print();

  employees[1]->print();

  employees[2]->print();
  employees[2]->pay();
  employees[2]->print();

  employees[3]->print();
  employees[3]->pay();
  employees[3]->print();

  employees[4]->print();
  employees[4]->pay();
  employees[4]->print();

  employees[5]->print();
  employees[5]->pay();
  employees[5]->print();
}

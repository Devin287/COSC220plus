#include "payroll.h"
#include<iostream>
using namespace std;

/*
 * I think the difference between the array of pointers
 * to payroll objects and array of payroll objects. Is that
 * the array of payroll objects stores bytes for each
 * parameter in the object so three ints and a string.
 * Which is 32 bytes and a total of 224 for all seven objects.
 * While the array of pointers to payroll objects is only
 * pointing to the adress that is only 8 bytes.
 */
 
int main()
{
  //Created an array of Payroll objects and intialized them
  //Was having an issue with default constructor being called
  //when array was intialized with 7 elements
  //so I initalized them in the declaration
  PayRoll emp[] = {PayRoll("Devin", 25),
  PayRoll("Michael", 11), PayRoll("Josh", 40),
  PayRoll("John", 33) ,PayRoll("Mich", 12),
  PayRoll("Joshua", 39), PayRoll("John Doe", 31) };

  //Created an array of pointers to PayRoll
  PayRoll* emp1[7];
  emp1[0] = new PayRoll("Devin", 25);
  emp1[1] = new PayRoll("Michael", 11);
  emp1[2] = new PayRoll("Josh", 40);
  emp1[3] = new PayRoll("John", 33);
  emp1[4] = new PayRoll("Mich", 12);
  emp1[5] = new PayRoll("Joshua", 39);
  emp1[6] = new PayRoll("John Doe", 31);

  int hours = 0;

   //Loop through both arrays of payroll objects to let user enter
   //number of hours though input validation
   for (int i = 0; i < 7; i++) {
     cout << "How many hours has employee #" << i
     << " worked?" << endl;
    if(hours >= 0 && hours < 60) //If is for input validation
    {
      cin >> hours;
      emp[i].setHoursWorked(hours);
      emp1[i]->setHoursWorked(hours);
    }
    else{
      cout << "Please enter a value greater than 0 and less than 60.\n";
      cin >> hours;
    }

  }
  //Printed the array of payroll objects
  for (int i =0; i < 7; i++)
  {
    emp[i].printEmps();
  }

//Seperation cout to seperate both array prints
cout << "-----------------------------------\n"
<<      "-------PAYROLL WITH POINTERS-------\n";

  //Printed array of pointers to payroll objects
  for (int i =0; i < 7; i++)
  {
    emp1[i]->printEmps();
  }

  //Printed sizeof for both arrays
  cout << "\nSize of emp is: " << sizeof(emp) << "\n";
  cout << "\nSize of emp1 is: " << sizeof(emp1) << "\n";
}

#include "payroll.h"
#include<iostream>
using namespace std;

//Method to set hours
void PayRoll::setHoursWorked(int h)
{
  hoursWorked = h;
}

//Method to get hours
int PayRoll::getHoursWorked()
{
  return hoursWorked;
}

//Method to calculate total pay
int PayRoll::getTotalPay()
{
  totalPay = hoursWorked * payRate;
  return totalPay;
}

//Method to print the arrays
void PayRoll::printEmps()
{
  cout << "The name of this employee is: " << name << '\n'
  << " Their hours worked is: " << hoursWorked << '\n'
  << " Their pay rate is $" << payRate << "/hr\n"
  << " Their total pay is: $"
  << getTotalPay() << '\n'
  << "\n";
}

//Default constructor
PayRoll::PayRoll()
{

}

//Construcotr that takes name and payrate
PayRoll::PayRoll(string n, int p)
{
  hoursWorked = 0;
  totalPay = 0;
  name = n;
  payRate = p;
}

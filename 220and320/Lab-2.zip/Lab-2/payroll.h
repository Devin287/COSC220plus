#ifndef PAYROLL_H
#define PAYROLL_H
#include<iostream>
using namespace std;

class PayRoll
{
private:
  //Private variables for class
  string name;
  int payRate;
  int hoursWorked;
  int totalPay;

public:
  //Public methods for class
  PayRoll();
  PayRoll(string name, int payRate);
  void setHoursWorked(int hoursWorked);
  int getHoursWorked();
  int getTotalPay();
  void printEmps();
};

#endif

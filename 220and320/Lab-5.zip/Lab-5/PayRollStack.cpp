#include "payroll.h"
#include "PayRollStack.h"
#include<iostream>
#include<stdio.h>
#include<string>
using namespace std;

//Default constructor
PayRollStack::PayRollStack()
{
  head = NULL;
}

//Destructor
PayRollStack::~PayRollStack()
{
  StackNode* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }
}

//Copy constructor
PayRollStack::PayRollStack(const PayRollStack &stack)
{

    head = new StackNode;
    head->p = stack.head->p;

  StackNode* currList = stack.head;
  StackNode* currCopy = head;

  currList = currList->next;

  while(currList != NULL)
  {
    currCopy->next = new StackNode;
    currCopy = currCopy->next;
    currCopy->p = currList->p;
    currList = currList->next;
  }
}

//Overloaded operator
PayRollStack PayRollStack::operator=(const PayRollStack &stack)
{
  StackNode* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }

if(this != &stack)
{
  if(head == NULL)
  {
      head = new StackNode;
      head->p = stack.head->p;
  }

    StackNode* currList = stack.head;
    StackNode* currCopy = head;

    currList = currList->next;

    while(currList != NULL)
    {
      currCopy->next = new StackNode;
      currCopy = currCopy->next;
      currCopy->p = currList->p;
      currList = currList->next;
    }
 }
    return *this;
}

//Inserts nodes into linkedlist
void PayRollStack::push(PayRoll p)
{
  StackNode* newNode = new StackNode;
  newNode->p = p;
  newNode->next = NULL;

   //Makes sure theres a head if not it makes one
  if(head == NULL)
  {
    newNode->next = head;
    head = newNode;
    return;
  }

  StackNode* curr = head;
  //loops through list and makes a newnode after head
  while(curr->next != NULL)
  {
      curr = curr->next;
  }
    newNode->next = curr->next;
    curr->next = newNode;
  //  head = newNode;
}

//Removes the last node inserted into the list
PayRoll PayRollStack::pop()
{
  StackNode* curr = head;
  PayRoll p;

  if(curr ==  NULL)
  {
    cout << "Empty";
  }

  while(curr->next != NULL)
  {
    curr = curr->next;
  }
  p = curr->p;
  delete curr;
  return p;
}

void PayRollStack::pop(PayRoll &p)
{
  p = pop();
}

//Prints list
void PayRollStack::printPayChecks()
{
  StackNode* tempPtr = head;
    while(tempPtr != NULL)
    {
      cout << "\n=============================================\n";
      cout << "Employee name: " << tempPtr->p.getName() << "\n";
      cout << "Total pay is: " << tempPtr->p.getTotalPay() << "\n";
      cout << "Rate: " << tempPtr->p.getPayRate() << "\n";
      cout << "Hours: " << tempPtr->p.getHoursWorked() << "\n";
      tempPtr = tempPtr->next;
      cout << "=============================================\n";
    }
}

//Size of the stack
int PayRollStack::size()
{
  StackNode* tempPtr = head;
  int count = 0;

    while(tempPtr != NULL)
    {
      tempPtr = tempPtr->next;
      count++;
    }
  return count;
}

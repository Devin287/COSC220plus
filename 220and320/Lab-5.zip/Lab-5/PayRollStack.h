#ifndef PAYROLLSTACK_H
#define PAYROLLSTACK_H
#include"payroll.h"
#include<stdio.h>
#include<iostream>
#include<bits/stdc++.h>
using namespace std;

class PayRollStack
{
private:
  struct StackNode{
    PayRoll p;
    StackNode* next;
  };

  StackNode* head;

  public:
    PayRollStack();
    ~PayRollStack();
    PayRollStack(const PayRollStack&);
    PayRollStack operator=(const PayRollStack&);
    void push(PayRoll p);
    PayRoll pop();
    void pop(PayRoll&);
    int size();
    void printPayChecks();
};

#endif

/*
 * Name:Devin schmidt
 * Course: COSC-220
 * Lab-5
 */

#include "payroll.h"
#include "PayRollStack.h"
#include<iostream>
#include<fstream>
using namespace std;

int main(int argc, char** argv)
{
//Creates a linkedlist object
PayRollStack emps;
//Creates Stream to acess file
ifstream file;
//Opens the file
file.open("empsList.txt");

string name = "";
double value = 0;
double value2 = 0;

for(int i = 0; i < 5; i++)
{
  while(file >> name >> value >> value2)
  {
    name = name;
    value = value;
    value2 = value2;
    emps.push(PayRoll(name,value,value2));
  }
}
//Create a PayRoll object using default constructor
PayRoll joe("Joe", 5.0, 5.0);
emps.push(joe);

//Closes file
file.close();
//emps.pop(); //Couldnt get this to work
emps.printPayChecks();
PayRollStack copyEmps(emps);//Calling copy constructor to make a new list

cout << "-----------------------COPIED STACK-----------------------";
              //Using copy constructor
//PayRoll p;
//emps.pop();
copyEmps.printPayChecks();

//Creating a second linkedlist
PayRollStack emps2;
//Using the overloaded = operator to copy the list
emps2 = emps;
cout << "\n-----------------------COPIED STACK2-----------------------";
                //Using = operator
emps2.printPayChecks();
}

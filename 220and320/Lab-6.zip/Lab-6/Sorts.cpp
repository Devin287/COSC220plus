#include "Sorts.h"
//#include<chrono>
using namespace std;

void Sorts::BubbleSort(int A[],int length)
{
  bool swapped = true;
  int swaps = 0;
  while(swapped)
  {
    swapped = false;
    for(int i = 0; i<length-1;i++)
    {
      if(A[i] > A[i+1])
      {
        int temp;
        temp = A[i];
        A[i] = A[i+1];
        A[i+1] = temp;
        swapped = true;
        swaps++;
      }
    }
   }
   cout << "Number of swaps for bubble sort is " << swaps;
   isSorted(A,length);
 }

 void Sorts::InsertionSort(int A[],int length)
 {
   int j = 0;
   int temp = 0;
   int swaps = 0;
    for(int i = 1; i<length;i++)
    {
      j=i;
      while(j>0 && A[j] < A[j-1])
      {
        temp = A[j];
        A[j] = A[j-1];
        A[j-1] = temp;
        j = j-1;
        swaps++;
      }
    }
    cout << "Number of swaps for insertion sort is " << swaps;
    isSorted(A,length);
 }

 void Sorts::SelectionSort(int A[],int length)
 {
   int swaps = 0;
   int min = 0;
   int temp = 0;
    for(int i = 0; i < length-1; i++)
    {
      min = i;
      for(int j = i + 1; j<length;j++)
      {
        if(A[j]<A[min])
        {
          min = j;
        }
      }
      temp = A[i];
      A[i] = A[min];
      A[min] = temp;
      swaps++;
    }
    cout << "Number of swaps for selection sort is " << swaps;
    isSorted(A,length);
 }

 void Sorts::isSorted(int A[],int length)
  {
     for(int i = 0; i<length-1;i++)
     {
       if(A[i] > A[i+1])
       {
         cout << "\nThe list is not sorted.\n";
         break;
       }
       else
       {
         cout << "\nThe list is sorted.\n";
         break;
       }
     }
  }

  void Sorts::printArr(int A[], int length)
  {
    for(int i = 0; i<length; i++)
      {
        cout << A[i] << " ";
      }
  }

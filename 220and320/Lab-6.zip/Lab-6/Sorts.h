#ifndef SORTS_H
#define SORTS_H
#include<iostream>
using namespace std;

class Sorts
{
  private:

  public:
    void BubbleSort(int A[],int length);
    void InsertionSort(int A[],int length);
    void SelectionSort(int A[],int length);
    void isSorted(int A[],int length);
    void printArr(int A[], int length);

  };

#endif

#include "Sorts.h"
#include<stdio.h>
#include<time.h>
#include<iostream>
#include<chrono>
using namespace std;

int main()
{
  int length1;
  length1 = 100;
  int accendingArr[length1];
  int decendingArr[length1];
  int *dynArr = new int[length1];
  Sorts bubble;
  srand(time(NULL));

cout << "****************One hundrend Sized test**********************\n";

/*                    Pure Garbage
 * From here down is repeated code that could probably
 * fixed to be more modular but its currently 2:30.
 * Each sort is called repeatedly wrapped around a timer
 * and the array is alllocated with unsorted values.
 */

for(int i = 0; i<length1; i++)
  {
    accendingArr[i] = i;
    //cout << accendingArr[i] << " ";
  }
int x = 0;
for(int i = length1-1; i>=0; i--)
  {
    decendingArr[i] = x;
    //cout << decendingArr[i] << " ";
    x++;

  }
for(int i = length1; i>=0; i--)
  {
    *(dynArr + i) = rand()% length1 + 1;
    //cout << *(dynArr + i) << " ";
  }


  cout << "Ascending\n";
  auto start = chrono::system_clock::now();
  bubble.BubbleSort(accendingArr,length1);
  auto end = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds = end-start;
  time_t end_time = chrono::system_clock::to_time_t(end);
  cout << "finished at " << ctime(&end_time)
       << "elapsed time: " << elapsed_seconds.count() << "s\n";
  for(int i = 0; i<length1; i++)
    {
      accendingArr[i] = i;
      //cout << accendingArr[i] << " ";
    }
  auto start1 = chrono::system_clock::now();
  bubble.InsertionSort(accendingArr,length1);
  auto end1 = chrono::system_clock::now();
  chrono::duration<double> elapsed1_seconds = end1-start1;
  time_t end1_time = chrono::system_clock::to_time_t(end1);
  cout << "finished at " << ctime(&end1_time)
       << "elapsed time: " << elapsed1_seconds.count() << "s\n";
  for(int i = 0; i<length1; i++)
    {
      accendingArr[i] = i;
      //cout << accendingArr[i] << " ";
    }
  auto start2 = chrono::system_clock::now();
  bubble.SelectionSort(accendingArr,length1);
  auto end2 = chrono::system_clock::now();
  chrono::duration<double> elapsed2_seconds = end2-start2;
  time_t end2_time = chrono::system_clock::to_time_t(end2);
  cout << "finished at " << ctime(&end2_time)
       << "elapsed time: " << elapsed2_seconds.count() << "s\n";

  cout << "\nDescending\n";
  auto start3 = chrono::system_clock::now();
  bubble.BubbleSort(decendingArr,length1);
  auto end3 = chrono::system_clock::now();
  chrono::duration<double> elapsed3_seconds = end3-start3;
  time_t end3_time = chrono::system_clock::to_time_t(end3);
  cout << "finished at " << ctime(&end3_time)
       << "elapsed time: " << elapsed3_seconds.count() << "s\n";
        x = 0;
       for(int i = length1-1; i>=0; i--)
         {
           decendingArr[i] = x;
           //cout << decendingArr[i] << " ";
           x++;

         }
  auto start4 = chrono::system_clock::now();
  bubble.InsertionSort(decendingArr,length1);
  auto end4 = chrono::system_clock::now();
  chrono::duration<double> elapsed4_seconds = end4-start4;
  time_t end4_time = chrono::system_clock::to_time_t(end4);
  cout << "finished at " << ctime(&end4_time)
       << "elapsed time: " << elapsed4_seconds.count() << "s\n";
       x = 0;
       for(int i = length1-1; i>=0; i--)
         {
           decendingArr[i] = x;
           //cout << decendingArr[i] << " ";
           x++;

         }
  auto start5 = chrono::system_clock::now();
  bubble.SelectionSort(decendingArr,length1);
  auto end5 = chrono::system_clock::now();
  chrono::duration<double> elapsed5_seconds = end5-start5;
  time_t end5_time = chrono::system_clock::to_time_t(end5);
  cout << "finished at " << ctime(&end5_time)
       << "elapsed time: " << elapsed5_seconds.count() << "s\n";

  cout << "\nRandomized\n";
  auto start6 = chrono::system_clock::now();
  bubble.BubbleSort(dynArr,length1);
  auto end6 = chrono::system_clock::now();
  chrono::duration<double> elapsed6_seconds = end6-start6;
  time_t end6_time = chrono::system_clock::to_time_t(end6);
  cout << "finished at " << ctime(&end6_time)
       << "elapsed time: " << elapsed6_seconds.count() << "s\n";
  for(int i = length1; i>=0; i--)
    {
      *(dynArr + i) = rand()% length1 + 1;
      //cout << *(dynArr + i) << " ";
    }
  auto start7 = chrono::system_clock::now();
  bubble.InsertionSort(dynArr,length1);
  auto end7 = chrono::system_clock::now();
  chrono::duration<double> elapsed7_seconds = end7-start7;
  time_t end7_time = chrono::system_clock::to_time_t(end7);
  cout << "finished at " << ctime(&end7_time)
       << "elapsed time: " << elapsed7_seconds.count() << "s\n";
  for(int i = length1; i>=0; i--)
    {
      *(dynArr + i) = rand()% length1 + 1;
      //cout << *(dynArr + i) << " ";
    }
  auto start8 = chrono::system_clock::now();
  bubble.SelectionSort(dynArr,length1);
  auto end8 = chrono::system_clock::now();
  chrono::duration<double> elapsed8_seconds = end8-start8;
  time_t end8_time = chrono::system_clock::to_time_t(end8);
  cout << "finished at " << ctime(&end8_time)
       << "elapsed time: " << elapsed8_seconds.count() << "s\n";
cout<< "\n";
  cout << "****************One hundrend thousand Sized test************\n";

  int length2;
  length2 = 10000;
  int ascendingArry[length2];
  int descendingArry[length2];
  int *dynArry = new int[length2];
  for(int i = 0; i<length2; i++)
    {
      ascendingArry[i] = i;
      //cout << ascendingArry[i] << " ";
    }

    x = 0;
    for(int i = length1-1; i>=0; i--)
      {
        descendingArry[i] = x;
        //cout << descendingArry[i] << " ";
        x++;

      }

    for(int i = length2; i>=0; i--)
      {
        *(dynArry + i) = rand()% length2 + 1;
        //cout << *(dynArr + i) << " ";
      }

      cout << "Ascending\n";
      auto start9 = chrono::system_clock::now();
      bubble.BubbleSort(ascendingArry,length2);
      auto end9 = chrono::system_clock::now();
      chrono::duration<double> elapsed9_seconds = end9-start9;
      time_t end9_time = chrono::system_clock::to_time_t(end9);
      cout << "finished at " << ctime(&end9_time)
           << "elapsed time: " << elapsed9_seconds.count() << "s\n";
      for(int i = 0; i<length2; i++)
        {
          ascendingArry[i] = i;
          //cout << accendingArr[i] << " ";
        }
      auto start11 = chrono::system_clock::now();
      bubble.InsertionSort(ascendingArry,length2);
      auto end11 = chrono::system_clock::now();
      chrono::duration<double> elapsed11_seconds = end11-start11;
      time_t end11_time = chrono::system_clock::to_time_t(end11);
      cout << "finished at " << ctime(&end11_time)
           << "elapsed time: " << elapsed11_seconds.count() << "s\n";
      for(int i = 0; i<length2; i++)
        {
          ascendingArry[i] = i;
          //cout << accendingArr[i] << " ";
        }
      auto start22 = chrono::system_clock::now();
      bubble.SelectionSort(ascendingArry,length2);
      auto end22 = chrono::system_clock::now();
      chrono::duration<double> elapsed22_seconds = end22-start22;
      time_t end22_time = chrono::system_clock::to_time_t(end22);
      cout << "finished at " << ctime(&end22_time)
           << "elapsed time: " << elapsed22_seconds.count() << "s\n";

      cout << "\nDescending\n";
      auto start33 = chrono::system_clock::now();
      bubble.BubbleSort(descendingArry,length2);
      auto end33 = chrono::system_clock::now();
      chrono::duration<double> elapsed33_seconds = end33-start33;
      time_t end33_time = chrono::system_clock::to_time_t(end33);
      cout << "finished at " << ctime(&end33_time)
           << "elapsed time: " << elapsed33_seconds.count() << "s\n";
           x = 0;
           for(int i = length1-1; i>=0; i--)
             {
               descendingArry[i] = x;
               //cout << descendingArry[i] << " ";
               x++;

             }
      auto start44 = chrono::system_clock::now();
      bubble.InsertionSort(descendingArry,length2);
      auto end44 = chrono::system_clock::now();
      chrono::duration<double> elapsed44_seconds = end44-start44;
      time_t end44_time = chrono::system_clock::to_time_t(end44);
      cout << "finished at " << ctime(&end44_time)
           << "elapsed time: " << elapsed44_seconds.count() << "s\n";
           x = 0;
           for(int i = length1-1; i>=0; i--)
             {
               descendingArry[i] = x;
               //cout << descendingArry[i] << " ";
               x++;

             }
      auto start55 = chrono::system_clock::now();
      bubble.SelectionSort(descendingArry,length2);
      auto end55 = chrono::system_clock::now();
      chrono::duration<double> elapsed55_seconds = end55-start55;
      time_t end55_time = chrono::system_clock::to_time_t(end);
      cout << "finished at " << ctime(&end55_time)
           << "elapsed time: " << elapsed55_seconds.count() << "s\n";

      cout << "\nRandomized\n";
      auto start66 = chrono::system_clock::now();
      bubble.BubbleSort(dynArry,length2);
      auto end66 = chrono::system_clock::now();
      chrono::duration<double> elapsed66_seconds = end66-start66;
      time_t end66_time = chrono::system_clock::to_time_t(end);
      cout << "finished at " << ctime(&end66_time)
           << "elapsed time: " << elapsed66_seconds.count() << "s\n";
      for(int i = length1; i>=0; i--)
        {
          *(dynArry + i) = rand()% length2 + 1;
          //cout << *(dynArr + i) << " ";
        }
      auto start77 = chrono::system_clock::now();
      bubble.InsertionSort(dynArry,length2);
      auto end77 = chrono::system_clock::now();
      chrono::duration<double> elapsed77_seconds = end77-start77;
      time_t end77_time = chrono::system_clock::to_time_t(end77);
      cout << "finished at " << ctime(&end77_time)
           << "elapsed time: " << elapsed77_seconds.count() << "s\n";
      for(int i = length2; i>=0; i--)
        {
          *(dynArry + i) = rand()% length2 + 1;
          //cout << *(dynArr + i) << " ";
        }
      auto start88 = chrono::system_clock::now();
      bubble.SelectionSort(dynArry,length2);
      auto end88 = chrono::system_clock::now();
      chrono::duration<double> elapsed88_seconds = end88-start88;
      time_t end88_time = chrono::system_clock::to_time_t(end88);
      cout << "finished at " << ctime(&end88_time)
           << "elapsed time: " << elapsed88_seconds.count() << "s\n";
cout << "\n";
  cout << "****************1 Million Sized test**********************\n";

  int length3;
  length3 = 90000;
  int ascendi[length3];
  int descendi[length3];
  int *dynArray = new int[length3];
  for(int i = 0; i<length3; i++)
    {
      ascendi[i] = i;
      //cout << ascendingArrMil[i] << " ";
    }

    x = 0;
    for(int i = length1-1; i>=0; i--)
      {
        descendi[i] = x;
        //cout << descendi[i] << " ";
        x++;

      }

    for(int i = length3; i>=0; i--)
      {
        *(dynArray + i) = rand()% length3 + 1;
        //cout << *(dynArr + i) << " ";
      }

      cout << "Ascending\n";
  /*bubble.BubbleSort(ascendi,length3);
      for(int i = 0; i<length3; i++)
        {
          ascendi[i] = i;
          //cout << accendingArr[i] << " ";
        }*/
      auto start99 = chrono::system_clock::now();
      bubble.InsertionSort(ascendi,length3);
      auto end99 = chrono::system_clock::now();
      chrono::duration<double> elapsed99_seconds = end99-start99;
      time_t end99_time = chrono::system_clock::to_time_t(end99);
      cout << "finished at " << ctime(&end99_time)
           << "elapsed time: " << elapsed99_seconds.count() << "s\n";
      for(int i = 0; i<length3; i++)
        {
          ascendi[i] = i;
          //cout << accendingArr[i] << " ";
        }
      auto start111 = chrono::system_clock::now();
      bubble.SelectionSort(ascendi,length3);
      auto end111 = chrono::system_clock::now();
      chrono::duration<double> elapsed111_seconds = end111-start111;
      time_t end111_time = chrono::system_clock::to_time_t(end111);
      cout << "finished at " << ctime(&end111_time)
           << "elapsed time: " << elapsed111_seconds.count() << "s\n";

      cout << "\nDescending\n";
      /*bubble.BubbleSort(descendi,length3);
      x = 0;
      for(int i = length1-1; i>=0; i--)
        {
          descendi[i] = x;
          //cout << descendi[i] << " ";
          x++;

        }*/
      auto start222 = chrono::system_clock::now();
      bubble.InsertionSort(descendi,length3);
      auto end222 = chrono::system_clock::now();
      chrono::duration<double> elapsed222_seconds = end222-start222;
      time_t end222_time = chrono::system_clock::to_time_t(end222);
      cout << "finished at " << ctime(&end222_time)
           << "elapsed time: " << elapsed222_seconds.count() << "s\n";
           x = 0;
           for(int i = length1-1; i>=0; i--)
             {
               descendi[i] = x;
               //cout << descendi[i] << " ";
               x++;

             }
      auto start333 = chrono::system_clock::now();
      bubble.SelectionSort(descendi,length3);
      auto end333 = chrono::system_clock::now();
      chrono::duration<double> elapsed333_seconds = end333-start333;
      time_t end333_time = chrono::system_clock::to_time_t(end333);
      cout << "finished at " << ctime(&end333_time)
           << "elapsed time: " << elapsed333_seconds.count() << "s\n";

      cout << "\nRandomized\n";
  /*bubble.BubbleSort(dynArray,length3);
      for(int i = length3; i>=0; i--)
        {
          *(dynArray + i) = rand()% length3 + 1;
          //cout << *(dynArr + i) << " ";
        }*/
      auto start444 = chrono::system_clock::now();
      bubble.InsertionSort(dynArray,length3);
      auto end444 = chrono::system_clock::now();
      chrono::duration<double> elapsed444_seconds = end444-start444;
      time_t end444_time = chrono::system_clock::to_time_t(end444);
      cout << "finished at " << ctime(&end_time)
           << "elapsed time: " << elapsed444_seconds.count() << "s\n";
      for(int i = length3; i>=0; i--)
        {
          *(dynArray + i) = rand()% length3 + 1;
          //cout << *(dynArr + i) << " ";
        }
      auto start555 = chrono::system_clock::now();
      bubble.SelectionSort(dynArray,length3);
      auto end555 = chrono::system_clock::now();
      chrono::duration<double> elapsed555_seconds = end555-start555;
      time_t end555_time = chrono::system_clock::to_time_t(end555);
      cout << "finished at " << ctime(&end555_time)
           << "elapsed time: " << elapsed555_seconds.count() << "s\n";
delete dynArr;
delete dynArry;
delete dynArray;

/*delete descendi;
delete descendingArry;
delete decendingArr;

delete ascendi;
delete ascendingArry;
delete accendingArr;*/
}

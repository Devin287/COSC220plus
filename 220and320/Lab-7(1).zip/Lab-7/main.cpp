#include<iostream>
using namespace std;

//Creating struct to hold data for linked list nodes
struct Node
{
  int value;
  Node* next;

  //Constructor
  Node()
  {
    value = 0;
    next = nullptr;
  }

  //Non-default ctor
  Node(int n)
  {
    value = n;
    next = nullptr;
  }

};

//Deallocates linked list to clear memory
Node* destructList(Node* head)
{
  Node* tempPtr = head;

  if(head == NULL)
  {
    return head;
  }
  else
  {
    delete head;
    return destructList(head->next);
    //head = tempPtr;
  }

}

//Prints the linked lists
Node* printList(Node* head)
{
  if(head == nullptr)
  {
    return head;
  }
  else
  {
    cout << head->value << "\n";
    printList(head->next);
  }
}

//Prints linked lists in reverse
Node* reversePrint(Node* head)
{
  if(head == nullptr)
  {
    return head;
  }
  else
  {
    reversePrint(head->next);
    cout << head->value << "\n";
  }
}

//Inserts a Node into linked list in a posistion that will maintain sort
Node* insertSorted(Node* head,int x)
{
  Node* newNode = new Node(x);

  if(head == NULL || head->value >= x )
  {
    newNode->next = head;
    head = newNode;
    return head;
  }
  if(head->next != NULL)
  {
    if(head->next->value < x)
    {
      return insertSorted(head->next,x);
    }
  }
   else
    {
      newNode->next = head->next;
      head->next = newNode;
    }
}

//Searches the linked list for a specific value
Node* search(Node* head,int target)
{
  if(head == nullptr || head->value == target)
  {
    return head;
  } else
    {
      return search(head->next,target);
    }

}

//Finds how many elements are in the linked list
 int length(Node* head)
 {
   if(head == nullptr)
   {
     return 0;
   }
   else
   {
     return 1+(length(head->next));
   }
  }

//Combines two linked lists
 Node* appendList(Node* head, Node* head2)
 {
   if(head == NULL)
   {
     return head;
   }

   if(head2 == NULL)
   {
     return head2;
   }

   else if(head->next == NULL)
   {
     head->next = head2;
     return head;
   }
   else
   {
     return appendList(head->next, head2);
   }
  }

  //Removesthe head of the linkedlist
  Node* remove(Node* head, int x)
  {
    Node* prev = head;

    if(head == nullptr)
    {
      return head;
    }

    if(head->value == x)
    {
      head = head->next;
      delete prev;
      return head;
    }
    else
    {
      remove(head->next,x);
    }
  }

//Tried getting the linked list to reverse
/*  Node* reverse(Node* head)
  {
    Node* tail = new Node();

    if(head == nullptr)
    {
      return 0;
    }
    if(head->next == NULL)
    {
      return head;
    }
    else
    {
      return reverse(head->next);
      tail = head;
    }
    return tail;
  }*/

//Main to test the methods
int main()
{
  //Created Nodes and pointed them to each other creating a linked list
  Node*head = new Node(1);
  head->next = nullptr;

  Node* newNode = new Node(2);
  newNode->next = nullptr;
  head->next = newNode;

  Node* newNode2 = new Node(3);
  newNode2->next = nullptr;
  newNode->next = newNode2;

  Node*head2 = new Node(4);
  head2->next = nullptr;

  Node* newNode3 = new Node(5);
  newNode3->next = nullptr;
  head2->next = newNode3;

  //Called methods and printed them to test for correctness
  cout << "First list from head:" <<"\n";
  printList(head);

  Node* head1 = new Node();
  head1 = appendList(head, head2);

  cout << "Second list appended to first list:" << "\n";
  printList(head);

  head1 = insertSorted(head,6);

  cout << "Inserted 6 to list:" << "\n";
  printList(head);

  Node* removeNode = new Node();
  //delete removeNode;
  removeNode = remove(head,1);

  cout << "Removed head from list:" << "\n";
  printList(removeNode);

  cout << "Reversed list:" << "\n";
  reversePrint(removeNode);

  //head = reverse(head);

  int len = length(removeNode);
  cout << "The length is: " << len << "\n";

//Trying to figure out how to get rid of mem leaks
  //destructList(head);
  //destructList(head1);
  //destructList(head2);
  destructList(removeNode);
  //destructList(newNode);
  //destructList(newNode2);
  //delete removeNode;
  //delete head1;
  //delete head2;
  //delete newNode;
  //delete newNode2;
}

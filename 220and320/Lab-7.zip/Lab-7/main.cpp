#include<iostream>
using namespace std;

//Creating struct to hold data for linked list nodes
struct Node
{
  int value;
  Node* next;

  //Constructor
  Node()
  {
    value = 0;
    next = nullptr;
  }

  //Non-default ctor
  Node(int n)
  {
    value = n;
    next = nullptr;
  }

};

//Deallocates linked list to clear memory
Node* destructList(Node* head)
{
  Node* tempPtr = head;

  if(head == NULL)
  {
    return head;
  }
  else
  {
    tempPtr = head->next;
    delete head;
    return destructList(tempPtr);
    //head = tempPtr;
  }

}

//Prints the linked lists
Node* printList(Node* head)
{
  if(head == nullptr)
  {
    return head;
  }
  else
  {
    cout << head->value << "\n";
    return printList(head->next);
  }
}

//Prints linked lists in reverse
Node* reversePrint(Node* head)
{
  if(head == nullptr)
  {
    return head;
  }
  else
  {
    reversePrint(head->next);
    cout << head->value << "\n";
    return head;
  }
}

//Inserts a Node into linked list in a posistion that will maintain sort
Node* insertSorted(Node* head,int x)
{


  if(head == NULL || head->value >= x )
  {
    Node* newNode = new Node(x);
    newNode->next = head;
    return newNode;
  }

  if(head->next != NULL)
  {
    if(head->next->value < x)
    {
      insertSorted(head->next,x);
      return head;
    }
    else
     {
       Node* newNode = new Node(x);
       newNode->next = head->next;
       head->next = newNode;
       return head;
     }
  } else {
    Node* newNode = new Node(x);
    head->next = newNode;
    return head;
  }
  return head;
}

//Searches the linked list for a specific value
Node* search(Node* head,int target)
{
  if(head == nullptr || head->value == target)
  {
    return head;
  } else
    {
      return search(head->next,target);
    }

}

//Finds how many elements are in the linked list
 int length(Node* head)
 {
   if(head == nullptr)
   {
     return 0;
   }
   else
   {
     return 1+(length(head->next));
   }
  }

//Combines two linked lists
 Node* appendList(Node* head, Node* head2)
 {
   if(head2 == NULL)
   {
     return head;
   }

   if(head == NULL)
   {
     return head2;
   }

   if(head->next == NULL)
   {
     head->next = head2;
     return head;
   }
   else
   {
     appendList(head->next, head2);
     return head;
   }
  }

  //Removesthe head of the linkedlist
  Node* remove(Node*& head, int x)
  {
    Node* prev = head;

    if(head == nullptr)
    {
      return head;
    }
    // if( head->next == nullptr ){

    // only happens on first call or if singleton list
    if(head->value == x){
      head = head->next;
      prev->next = nullptr;
      return prev;
    } else {
      return nullptr;
    }
    // }

    if(head->next->value == x)
    {
      prev = head->next;
      head->next = head->next->next;
      // delete prev;
      prev->next = nullptr;
      return prev;
    }
    else
    {
      return remove(head->next,x);
    }
  }

//Tried getting the linked list to reverse
  Node* reverse(Node* head)
  {
    if(head == nullptr)
    {
      return 0;
    }
    if(head->next == nullptr)
    {
      return head;
    }
    else
    {
      Node* tail = reverse(head->next);
      head->next->next = head;
      head->next = nullptr;
      return tail;
    }
  }

//Main to test the methods
int main()
{
  //Created Nodes and pointed them to each other creating a linked list
  Node*head = new Node(1);
  head->next = nullptr;
  //
  // Node* newNode = new Node(2);
  // newNode->next = nullptr;
  head->next = new Node(2);

  // Node* newNode2 = new Node(3);
  // newNode2->next = nullptr;
  head->next->next = new Node(3);

  // Node*head2 = new Node(4);
  // head2->next = nullptr;

  // Node* newNode3 = new Node(6);
  // newNode3->next = nullptr;
  head->next->next->next = new Node(6);

  //Called methods and printed them to test for correctness
  cout << "First list from head:" <<"\n";
  printList(head);

  Node* head1 = new Node(10);
  head = appendList(head, head1);
  head1 = nullptr;

  cout << "Second list appended to first list:" << "\n";
  printList(head);

  head = insertSorted(head,5);

  cout << "Inserted 5 to list:" << "\n";
  printList(head);

  Node* removeNode = nullptr; // = new Node();
  //delete removeNode;
  removeNode = remove(head,1);

  cout << "Removed head from list:" << "\n";
  printList(removeNode);
  printList(head);

  cout << "Reversed print list:" << "\n";
  reversePrint(head);

   head = reverse(head);

  cout << "Reversed list:" << "\n";
  printList(head);

  int len = length(head);
  cout << "The length is: " << len << "\n";

//Trying to figure out how to get rid of mem leaks
  destructList(head);
  // destructList(head1);
  destructList(head1);
  destructList(removeNode);
  // destructList(newNode);
  // destructList(newNode2);
  // delete removeNode;
  // delete head1;
  // delete head2;
  // delete newNode;
  // delete newNode2;
}

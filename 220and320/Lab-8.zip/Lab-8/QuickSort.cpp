/*
 *Devin Schmidt
 *COSC-220
 *Fall 2019
 *Lab-8
 */

#include<iostream>
#include<chrono>
#include<time.h>
using namespace std;

void swap(int &val1, int &val2)
{
  int tempVal = val1;
  val1 = val2;
  val2 = tempVal;
}

int partition(int arr[], int start, int end)
{
  int pivt;
  int centerIndex;
  int pivtIndex;

  centerIndex = (start + end) / 2;
  swap(arr[start], arr[centerIndex]);
  pivtIndex = start;
  pivt = arr[start];

    for(int i = start+1; i <= end; i++)
    {
      if(arr[i] < pivt)
      {
        pivtIndex++;
          swap(arr[pivtIndex], arr[i]);
      }
    }
    swap(arr[start], arr[pivtIndex]);
    return pivtIndex;
}

int partition2(int arr[], int start, int end)
{
  int pivt;
  int centerIndex;
  int pivtIndex;

  centerIndex = (start + end) / 2;
  swap(arr[start], arr[centerIndex]);
  pivtIndex = start;
  pivt = arr[start];

    for(int i = start+1; i <= end; i++)
    {
      if(arr[i] < pivt)
      {
        pivtIndex++;
          swap(arr[pivtIndex], arr[i]);
      }
    }
    swap(arr[start], arr[pivtIndex]);
    cout << "\nThe pivot is: " << pivt << "\nThe pivots location is: "
         << pivtIndex << endl;
    return pivtIndex;
}

void quickSort(int arr[], int start, int end)
{
  if(start >= end){
  }
  else
  {
    int pivt = partition(arr,start,end);
    quickSort(arr, start,pivt-1);
    quickSort(arr,pivt+1,end);
  }
}

void printArr(int A[], int length)
{
  for(int i = 0; i<length; i++)
    {
      cout << A[i] << " ";
    }
}

void dynAllocArrFunction()
{
  int *dynArr = new int[10000000];

  for(int i = 10000000; i>=0; i--)
    {
      *(dynArr + i) = rand()% 10000000 + 1;
      //cout << *(dynArr + i) << " ";
    }

    auto start = chrono::system_clock::now();
    quickSort(dynArr,0,10000000);
    auto end = chrono::system_clock::now();
    chrono::duration<double> elapsed_seconds = end-start;
    time_t end_time = chrono::system_clock::to_time_t(end);
    cout << "finished at " << ctime(&end_time)
         << "elapsed time: " << elapsed_seconds.count() << "s\n";
}

int main()
{
  int a = 10;
  int b = 5;

  cout << "\nFirst swap test.\n";
  cout << "a: " << a << endl << "b: " << b <<endl;
  swap(a,b);
  cout << "a: " << a << endl << "b: " << b <<endl;

  cout << "\nNext swap test.\n";

  int arr[] = {11,6};
  cout << "a: " << arr[0] << endl << "b: " << arr[1] <<endl;
  swap(arr[0],arr[1]);
  cout << "a: " << arr[0] << endl << "b: " << arr[1] <<endl;

  int arr2[] = {11,7,12,34,435,546,54,44,23,34,45};
  cout << "\nPartition test.\n";
  partition2(arr2,0,10);
  cout << "\nQuickSort test.\n";
  quickSort(arr2,0,10);
  printArr(arr2,11);

  cout << "\nTrying accending and decnding sorted arrays.\n";

  int accendingArr[100];
  int decendingArr[100];

  for(int i = 0; i<100; i++)
    {
      accendingArr[i] = i;
      cout << accendingArr[i] << " ";
    }

  cout <<endl;

  int x = 0;
  for(int i = 100-1; i>=0; i--)
    {
      decendingArr[x] = i;
      x++;
    }
    printArr(decendingArr,100);
    cout << "\n" << "Accending array sort.\n";
    quickSort(accendingArr,0,100);
    printArr(accendingArr,100);
    cout << "\n" << "Decending array sort.\n";
    quickSort(decendingArr,0,100-1);
    printArr(decendingArr,100-1);
    cout << endl;

    cout << "\nTrying large random arrays.\n";

    dynAllocArrFunction();

  return 0;
}

#include "payroll.h"
#include "MyStack.h"

//Default constructor
MyStack::MyStack()
{
  head = NULL;
}

//Destructor
MyStack::~MyStack()
{
  StackNode* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }
}

//Copy constructor
MyStack::MyStack(const MyStack &stack)
{

    head = new StackNode;
    head->data = stack.head->data;

  StackNode* currList = stack.head;
  StackNode* currCopy = head;

  currList = currList->next;

  while(currList != NULL)
  {
    currCopy->next = new StackNode;
    currCopy = currCopy->next;
    currCopy->data = currList->data;
    currList = currList->next;
  }
}

//Overloaded operator
MyStack MyStack::operator=(const MyStack &stack)
{
  StackNode* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }

if(this != &stack)
{
  if(head == NULL)
  {
      head = new StackNode;
      head->data = stack.head->data;
  }

    StackNode* currList = stack.head;
    StackNode* currCopy = head;

    currList = currList->next;

    while(currList != NULL)
    {
      currCopy->next = new StackNode;
      currCopy = currCopy->next;
      currCopy->data = currList->data;
      currList = currList->next;
    }
 }
    return *this;
}

//Inserts nodes into linkedlist
void MyStack::push(PayRoll p)
{
  StackNode* newNode = new StackNode;
  newNode->data = p;
  newNode->next = NULL;

   //Makes sure theres a head if not it makes one
  if(head == NULL)
  {
    newNode->next = head;
    head = newNode;
    return;
  }

  StackNode* curr = head;
  //loops through list and makes a newnode after head
  while(curr->next != NULL)
  {
      curr = curr->next;
  }
    newNode->next = curr->next;
    curr->next = newNode;
  //  head = newNode;
}

//Removes the last node inserted into the list
PayRoll MyStack::pop()
{
  StackNode* curr = head;
  StackNode* prev = head;
  PayRoll p;

  if(curr ==  NULL)
  {
    cout << "Empty";
    return p;
  }

  while(curr->next != NULL)
  {
    prev = curr;
    curr = curr->next;

  }
  p = curr->data;
  delete curr;
  prev->next = NULL;
  return p;
}

void MyStack::pop(PayRoll &p)
{
  p = pop();
}

//Prints list
void MyStack::printPayChecks()
{
  StackNode* tempPtr = head;
    while(tempPtr != NULL)
    {
      cout << "\n=============================================\n";
      cout << "Employee name: " << tempPtr->data.getName() << "\n";
      cout << "Total pay is: " << tempPtr->data.getTotalPay() << "\n";
      cout << "Rate: " << tempPtr->data.getPayRate() << "\n";
      cout << "Hours: " << tempPtr->data.getHoursWorked() << "\n";
      tempPtr = tempPtr->next;
      cout << "=============================================\n";
    }
}

//Size of the stack
int MyStack::size()
{
  StackNode* tempPtr = head;
  int count = 0;

    while(tempPtr != NULL)
    {
      tempPtr = tempPtr->next;
      count++;
    }
  return count;
}

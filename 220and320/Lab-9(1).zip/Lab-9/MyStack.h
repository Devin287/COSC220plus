#ifndef MYSTACK_H
#define MYSTACK_H

#include "payroll.h"
#include<iostream>
#include<fstream>
using namespace std;

//template<class T>
class MyStack
{
private:
  struct StackNode{
    PayRoll data;
    StackNode* next;
  };

  StackNode* head;

  public:
    MyStack();
    ~MyStack();
    MyStack(const MyStack&);
    MyStack operator=(const MyStack&);
    void push(PayRoll p);
    PayRoll pop();
    void pop(PayRoll&);
    int size();
    void printPayChecks();
};

#endif

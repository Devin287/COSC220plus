#ifndef PAYROLL_H
#define PAYROLL_H

class PayRoll
{
private:
  //Private variables for class
  string name;
  double payRate;
  double hoursWorked;
  double totalPay;

public:
  //Public methods for class
  PayRoll();
  PayRoll(string name, double payRate, double hoursWorked);
  void setHoursWorked(double hoursWorked);
  void setName(string name);
  void setRate(double payRate);
  double getHoursWorked();
  double getTotalPay();
  double getPayRate();
  string getName();
  void printEmps();
};

#endif

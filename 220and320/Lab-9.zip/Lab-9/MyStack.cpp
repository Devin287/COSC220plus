#include "payroll.h"
#include "MyStack.h"
#include<iostream>
#include<stdio.h>
#include<string>

//Default constructor
template<class T>
MyStack<T>::MyStack()
{
  head = NULL;
}

//Destructor
template<class T>
MyStack<T>::~MyStack()
{
  StackNode* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }
}

//Copy constructor
template<class T>
MyStack<T>::MyStack(const MyStack &stack)
{

    head = new StackNode;
    head->data = stack.head->data;

  StackNode* currList = stack.head;
  StackNode* currCopy = head;

  currList = currList->next;

  while(currList != NULL)
  {
    currCopy->next = new StackNode;
    currCopy = currCopy->next;
    currCopy->data = currList->data;
    currList = currList->next;
  }
}

//Overloaded operator
template<class T>
MyStack<T> MyStack<T>::operator=(const MyStack &stack)
{
  StackNode* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }

if(this != &stack)
{
  if(head == NULL)
  {
      head = new StackNode;
      head->data = stack.head->data;
  }

    StackNode* currList = stack.head;
    StackNode* currCopy = head;

    currList = currList->next;

    while(currList != NULL)
    {
      currCopy->next = new StackNode;
      currCopy = currCopy->next;
      currCopy->data = currList->data;
      currList = currList->next;
    }
 }
    return *this;
}

//Inserts nodes into linkedlist
template<class T>
void MyStack<T>::push(T p)
{
  StackNode* newNode = new StackNode;
  newNode->data = p;
  newNode->next = NULL;

   //Makes sure theres a head if not it makes one
  if(head == NULL)
  {
    newNode->next = head;
    head = newNode;
    return;
  }

  StackNode* curr = head;
  //loops through list and makes a newnode after head
  while(curr->next != NULL)
  {
      curr = curr->next;
  }
    newNode->next = curr->next;
    curr->next = newNode;
}

//Removes the last node inserted into the list
template<class T>
T MyStack<T>::pop()
{
  StackNode* curr = head;
  StackNode* prev = head;
  T data;

  if(curr ==  NULL)
  {
    std::cout << "Empty";
    return data;
  }

  while(curr->next != NULL)
  {
    prev = curr;
    curr = curr->next;

  }
  data = curr->data;
  delete curr;
  prev->next = NULL;
  return data;
}

template<class T>
void MyStack<T>::pop(T &data)
{
  data = pop();
}

template<class T>
std::ostream& operator<<(std::ostream &oStream,MyStack<T> &s)
{
  return s.printPayChecks(oStream);
}

//Prints list
template<class T>
std::ostream& MyStack<T>::printPayChecks(std::ostream& oStream)
{
  StackNode* tempPtr = head;
    while(tempPtr != NULL)
    {
      oStream << "\n=============================================\n";
      oStream << "Employee name: " << tempPtr->data.getName() << "\n";
      oStream << "Total pay is: " << tempPtr->data.getTotalPay() << "\n";
      oStream << "Rate: " << tempPtr->data.getPayRate() << "\n";
      oStream << "Hours: " << tempPtr->data.getHoursWorked() << "\n";
      tempPtr = tempPtr->next;
      oStream << "=============================================\n";
    }
    return oStream;
}

//Checks to see what value is on top
template<class T>
T MyStack<T>::peak()
{
  T data;
  StackNode* tempPtr = head;
  return data;
}

//Size of the stack
template<class T>
int MyStack<T>::size()
{
  StackNode* tempPtr = head;
  int count = 0;

    while(tempPtr != NULL)
    {
      tempPtr = tempPtr->next;
      count++;
    }
  return count;
}

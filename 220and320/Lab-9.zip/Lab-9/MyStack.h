#ifndef MYSTACK_H
#define MYSTACK_H
#include"payroll.h"
#include<stdio.h>
#include<iostream>
#include<bits/stdc++.h>

template <class T>
class MyStack
{
private:

  struct StackNode{
    T data;
    StackNode* next;
  };

  StackNode* head;

  public:
    MyStack<T>();
    ~MyStack();
    MyStack(const MyStack&);
    MyStack operator=(const MyStack<T>&);
    void push(T data);
    T pop();
    void pop(T&);
    T peak();
    int size();
    std::ostream& printPayChecks(std::ostream&);
    template <class J>
    friend std::ostream& operator<<(std::ostream& oStream,MyStack<J> &s);
};

#endif

/*
 * Name:Devin schmidt
 * Course: COSC-220
 * Lab-5
 */

#include "payroll.h"
#include "MyStack.h"
#include "MyStack.cpp"
#include<iostream>
#include<fstream>

int main(int argc, char** argv)
{
  //Creates a linkedlist object
  MyStack<PayRoll> emps;
  //Creates Stream to acess file
  std::ifstream file;
  //Opens the file
  file.open("empsList.txt");

  std::string name = "";
  double value = 0;
  double value2 = 0;

  //Loops through file taking the data from it and passing it to the stack
  for(int i = 0; i < 5; i++)
  {
    while(file >> name >> value >> value2)
    {
      name = name;
      value = value;
      value2 = value2;
      emps.push(PayRoll(name,value,value2));
    }
  }
  //Create a PayRoll object using default constructor
  PayRoll joe("Jo", 5.0, 5.0);
  emps.push(joe);

  //Closes file
  file.close();
  emps.pop(); //Couldnt get this to work
  std::cout << emps;
  MyStack<PayRoll>copyEmps(emps);//Calling copy constructor to make a new list

  std::cout << "-----------------------COPIED STACK-----------------------";
                //Using copy constructor
  std::cout << copyEmps;

  //Creating a second linkedlist
  MyStack<PayRoll> emps2;
  //Using the overloaded = operator to copy the list
  emps2 = emps;
  emps2.pop();
  std::cout << "\n-----------------------COPIED STACK2-----------------------";
                  //Using = operator
  emps2.push(joe);
  emps2.push(joe);
  std::cout << emps2 << std::endl;

  emps.peak();

  //MyStack<std::string> strStack;
  //strStack.push(PayRoll("HI"));
  //std::cout << strStack;



}

#include "payroll.h"
#include "MyStack.h"
#include<iostream>

//Method to set hours
void PayRoll::setHoursWorked(double h)
{
  hoursWorked = h;
}

void PayRoll::setRate(double r)
{
  payRate = r;
}

void PayRoll::setName(std::string n)
{
  name = n;
}

std::string PayRoll::getName()
{
  return name;
}

//Method to get hours
double PayRoll::getHoursWorked()
{
  return hoursWorked;
}

//Method to calculate total pay
double PayRoll::getTotalPay()
{
  totalPay = payRate * hoursWorked;
  return totalPay;
}

double PayRoll::getPayRate()
{
  return payRate;
}

//Method to print the arrays
void PayRoll::printEmps()
{
  std::cout << "The name of this employee is: " << name << '\n'
  << " Their hours worked is: " << hoursWorked << '\n'
  << " Their pay rate is $" << payRate << "/hr\n"
  << " Their total pay is: $"
  << getTotalPay() << '\n'
  << "\n";
}

//Default constructor
PayRoll::PayRoll()
{

}

//Construcotr that takes name and payrate
PayRoll::PayRoll(std::string n, double p, double h)
{
  this->setName(n);
  this->setRate(p);
  this->setHoursWorked(h);
}

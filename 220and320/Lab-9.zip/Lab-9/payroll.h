#ifndef PAYROLL_H
#define PAYROLL_H
#include<iostream>

class PayRoll
{
private:
  //Private variables for class
  std::string name;
  double payRate;
  double hoursWorked;
  double totalPay;

public:
  //Public methods for class
  PayRoll();
  PayRoll(std::string name, double payRate, double hoursWorked);
  void setHoursWorked(double hoursWorked);
  void setName(std::string name);
  void setRate(double payRate);
  double getHoursWorked();
  double getTotalPay();
  double getPayRate();
  std::string getName();
  void printEmps();
};

#endif

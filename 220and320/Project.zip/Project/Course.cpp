#include<iostream>
#include<stdio.h>
#include<string>
#include "Course.h"
using namespace std;

//Default constructor
Course::Course()
{

}

//Constructor that takes courseName, dept, semester, and grdRecieved
Course::Course(string c, string d, string s, double g)
{
  this->setCourseName(c);
  this->setDept(d);
  this->setSemester(s);
  this->setGrdRecieved(g);
}

void Course::setGrdRecieved(double g)
{
  grdRecieved = g;
}

void Course::setCourseName(string c)
{
  courseName = c;
}

void Course::setDept(string d)
{
  dept = d;
}

void Course::setSemester(string s)
{
  semester = s;
}

string Course::getCourseName()
{
  return courseName;
}

//Method to get hours
double Course::getGrdRecieved()
{
  return grdRecieved;
}

//Method to calculate total pay
string Course::getDept()
{
  return dept;
}

string Course::getSemester()
{
  return semester;
}

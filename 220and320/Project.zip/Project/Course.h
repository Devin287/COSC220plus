#ifndef COURSE_H
#define COURSE_H
#include<stdio.h>
#include<iostream>
using namespace std;

class Course
{
private:
  //Private variables for class
  string courseName;
  string dept;
  string semester;
  double grdRecieved;

public:
  //Public methods for class
  Course();
  Course(string courseName, string dept, string semester, double grdRecieved);
  void setGrdRecieved(double grdRecieved);
  void setCourseName(string courseName);
  void setDept(string dept);
  void setSemester(string semester);
  double getGrdRecieved();
  string getCourseName();
  string getDept();
  string getSemester();
};
#endif

#include "Course.h"
#include "StudentDB.h"
#include "Student.h"
#include<iostream>
#include<stdio.h>
#include<string>
using namespace std;

//Default constructor
Student::Student()
{

}

Student::Student(string n,string d, string m)
{
  head = NULL;
  this->setName(n);
  this->setDateOB(d);
  this->setMajor(m);
}

//Destructor
/*Student::~Student()
{
  ListNode* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }
}*/

//Inserts nodes into linkedlist
void Student::insert(Course t)
{
  insert(t.getCourseName(), t.getDept(), t.getSemester(), t.getGrdRecieved());
}

void Student::insert(string c,string d,string s,double g)
{
  ListNode* newNode = new ListNode;
  Course l(c,d,s,g);
  newNode->c = l;
  newNode->next = NULL;

   //Makes sure theres a head if not it makes one
  if(head == NULL)
  {
    newNode->next = head;
    head = newNode;
    return;
  }

  ListNode* curr = head;
  //loops through list and makes a newnode after head
  while(curr->next != NULL)
  {
      curr = curr->next;
  }
    newNode->next = curr->next;
    curr->next = newNode;

}

//Prints list
void Student::printStudent()
{
  ListNode* tempPtr = head;
    while(tempPtr != NULL)
    {
      cout << "\n=============================================\n";
      cout << "Course Name: " << tempPtr->c.getCourseName() << "\n";
      cout << "Department: " << tempPtr->c.getDept() << "\n";
      cout << "Semester: " << tempPtr->c.getSemester() << "\n";
      cout << "Grade Recieved: " << tempPtr->c.getGrdRecieved() << "\n";
      tempPtr = tempPtr->next;
      cout << "=============================================\n";
    }
}

int Student::length()
{
  ListNode* tempPtr = head;
  int count = 0;

    while(tempPtr != NULL)
    {
      tempPtr = tempPtr->next;
      count++;
    }
  return count;
}

Course* Student::operator[](int x)
{
  ListNode* tempPtr = head;
  int pos = 0;

    while(tempPtr != NULL)
    {
      tempPtr = tempPtr->next;
      pos++;

      if(pos == x)
      {
        return &(tempPtr->c);
      }
    }
}

void Student::remove(string cName)
{
  ListNode* curr = head;
  ListNode* prev = head;

  if(curr->c.getCourseName().compare(cName) == 0)
  {
    head = head->next;
    delete prev;
    return;
  }

    while(curr)
    {
      prev = curr;
      curr = curr->next;

      if(curr->c.getCourseName().compare(cName) == 0)
      {
        prev->next = curr->next;
        delete curr;
      }
    }
}

void Student::removeAll()
{
  ListNode* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }
}

void Student::assign(int x, Course p)
{
  *((*this)[x]) = p;
}

void Student::insert(int x, Course p)
{
  ListNode* curr = head;
  ListNode* prev = head;
  ListNode* newNode = new ListNode;

  int pos = 0;

  while(curr != NULL)
  {
    if(pos != x)
    {
      curr = curr->next;
      pos++;
      cout <<"pos" <<pos;
    }
    break;
  }

    newNode->c = p;
    newNode->next = curr->next;
    curr->next = newNode;
}

void Student::setName(string n)
{
  name = n;
}

void Student::setDateOB(string d)
{
  dateOB = d;
}

void Student::setMajor(string m)
{
  major = m;
}

string Student::getName()
{
  return name;
}

string Student::getDateOB()
{
  return dateOB;
}

string Student::getMajor()
{
  return major;
}

#ifndef STUDENT_H
#define STUDENT_H
#include "Course.h"
#include<stdio.h>
#include<iostream>
using namespace std;

class Student
{
private:
  struct ListNode{
    Course c;
    ListNode* next;
  };

  ListNode* head;
  string name;
  string dateOB;
  string major;

  public:
    Student();
    Student(string name,string dateOB,string major);
    //~Student();
    int length();
    void insert(Course);
    void insert(string,string,string,double);
    void insert(int, Course);
    Course* operator[](int);
    void remove(string cName);
    void removeAll();
    void assign(int, Course);
    void printStudent();
    void setName(string name);
    void setDateOB(string dateOB);
    void setMajor(string major);
    string getName();
    string getDateOB();
    string getMajor();
};

#endif

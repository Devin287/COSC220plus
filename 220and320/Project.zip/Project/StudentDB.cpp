#include<iostream>
#include<stdio.h>
#include<string>
#include "Course.h"
#include "Student.h"
#include "StudentDB.h"
using namespace std;

//Default constructor
StudentDB::StudentDB()
{
  head = NULL;
}

//Destructor
StudentDB::~StudentDB()
{
  //~Student();
  ListNode2* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }
}

//Inserts nodes into linkedlist
void StudentDB::insert(Student t)
{
  insert(t.getName(), t.getDateOB(), t.getMajor());
}

void StudentDB::insert(string n,string d,string m)
{
  ListNode2* newNode = new ListNode2;
  Student t(n,d,m);
  newNode->s = t;
  newNode->next = NULL;

   //Makes sure theres a head if not it makes one
  if(head == NULL)
  {
    newNode->next = head;
    head = newNode;
    return;
  }

  ListNode2* curr = head;
  //loops through list and makes a newnode after head
  while(curr->next != NULL)
  {
      curr = curr->next;
  }
    newNode->next = curr->next;
    curr->next = newNode;

}

//Prints list
void StudentDB::printStudentDB()
{
  ListNode2* tempPtr = head;
    while(tempPtr)
    {
      cout << "\n=============================================\n";
      cout << "Name: " << tempPtr->s.getName() << "\n";
      cout << "Date of Birth: " << tempPtr->s.getDateOB() << "\n";
      cout << "Major: " << tempPtr->s.getMajor() << "\n";
      tempPtr->s.printStudent();
      tempPtr = tempPtr->next;
      cout << "\n=============================================\n";
    }
}

//Tracks the size of the linkedlist
int StudentDB::length()
{
  ListNode2* tempPtr = head;
  int count = 0;

    while(tempPtr != NULL)
    {
      tempPtr = tempPtr->next;
      count++;
    }
  return count;
}

//Overloaded operator 
Student* StudentDB::operator[](int x)
{
  ListNode2* tempPtr = head;
  int pos = 0;

    while(tempPtr != NULL)
    {
      tempPtr = tempPtr->next;
      pos++;
      if(pos == x)
      {
        return &(tempPtr->s);
      }
    }
}

StudentDB StudentDB::operator=(const StudentDB &list)
{
if(this != &list)
{
  if(head == NULL)
  {
      head = new ListNode2;
      head->s = list.head->s;
  }

    ListNode2* currList = list.head;
    ListNode2* currCopy = head;

    currList = currList->next;

    while(currList != NULL)
    {
      currCopy->next = new ListNode2;
      currCopy = currCopy->next;
      currCopy->s = currList->s;
      currList = currList->next;
    }
 }
    return *this;
}

void StudentDB::remove(string sName)
{
    ListNode2* curr = head;
    ListNode2* prev = head;

    if(curr->s.getName().compare(sName) == 0)
    {
      curr->s.removeAll();
      head = head->next;
      delete prev;
      return;
    }

      while(curr)
      {
        prev = curr;
        curr = curr->next;

        if(curr->s.getName().compare(sName) == 0)
        {
          curr->s.removeAll();
          prev->next = curr->next;
          delete curr;
        }
      }
}

void StudentDB::assign(int x, Student p)
{
  *((*this)[x]) = p;
}

void StudentDB::search(string sName,string cName,string dep,string term,double grade)
{
  ListNode2* tempPtr = head;
    while(tempPtr)
    {
      if(tempPtr->s.getName().compare(sName) == 0)
      {
        tempPtr->s.insert(cName,dep,term,grade);
      }
    tempPtr = tempPtr->next;
    }
}

/*void StudentDB::insert(int x, Student p)
{
  ListNode* curr = head;
  ListNode* prev = head;
  ListNode* newNode = new ListNode;

  int pos = 0;

  while(curr != NULL)
  {
    if(pos != x)
    {
      curr = curr->next;
      pos++;
      cout <<"pos" <<pos;
    }
    break;
  }

    newNode->s = p;
    newNode->next = curr->next;
    curr->next = newNode;
}*/

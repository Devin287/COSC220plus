#ifndef STUDENTDB_H
#define STUDENTDB_H
#include "Student.h"
#include "Course.h"
#include<stdio.h>
#include<iostream>
using namespace std;

class StudentDB
{
private:
  struct ListNode2{
    Student s;
    ListNode2* next;
  };

  ListNode2* head;

  public:
    StudentDB();
    ~StudentDB();
    int length();
    void insert(Student);
    void insert(string n,string d,string m);
    Student* operator[](int);
    StudentDB operator=(const StudentDB &list);
    void remove(string sName);
    void assign(int, Student);
    void printStudentDB();
    void printStudent();
    void search(string sName,string cName,string dep,string term,double grade);
};

#endif

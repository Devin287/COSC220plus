/*
 * Name:Devin schmidt
 * Course: COSC-220
 * Project
 */

#include "StudentDB.h"
#include "Student.h"
#include "Course.h"
#include<iostream>
#include<string>
#include<sstream>
#include<fstream>
using namespace std;

int main(int argc, char** argv)
{
//Creating
char answer = 'y';
char answer2 = 'y';
string userMajor;
//Created database linked list object
StudentDB dataBase;
ifstream file;
ofstream inFile;
//Opened the files to read a list of majors and to allow user to add majors
file.open("Majors.txt");
inFile.open("Majors.txt",ios::app);
string name;

//****Start of  allowing user to enter in the information for the database****
cout << "Would you like enter students? 'y' or 'n'";
cin >> answer;
cin.ignore();

while(answer != 'y' && answer != 'n')
{
  cin.clear();
  cout << "Invalid charcter please use 'y' or 'n'";
  cin >> answer;
}
  while(answer == 'y')
  {
    string sName;
    string DoB;
    string major;

    cout << "What is the students name?";
    getline(cin,sName);
    cin.ignore();

    cout << "What is the students Date of Birth (Example format(5/3/1998))?";
    cin >>DoB;
    cin.ignore();


    while(file >> name)
    {
      name = name;
      cout << "\n" << name << "\n";
    }
    cout << "Would you like to add a major? 'y' or 'n'";
    cin >> answer;
    cin.ignore();

          while(answer != 'y' && answer != 'n')
          {
            cin.clear();
            cout << "Invalid charcter please use 'y' or 'n'";
            cin >> answer;
          }
                  if(answer == 'y')
                  {
                      cout << "What is the major?";
                      cin >> userMajor;
                      inFile << userMajor;
                  }

    cout << "What is the students major?";
    getline(cin,major);
    file.close();
    inFile.close();

    dataBase.insert(Student(sName,DoB,major));

    cout << "Would you like enter more students? 'y' or 'n'";
    cin >> answer;
    cin.ignore();
  }

  cout << "Would you like to add courses to a student? 'y' or 'n'";
  cin >> answer;

  if(answer == 'y')
  {
    string sName;
    string cName;
    string dep;
    string term;
    double grade;

    cout << "What is the students name?";
    cin >> sName;
    cin.ignore();

      while(answer == 'y')
      {
        cout << "What is the course name?";
        getline(cin,cName);
        cin.ignore();

        cout << "What is the courses department?";
        getline(cin,dep);
        cin.ignore();

        cout << "What term was the course taken?";
        getline(cin,term);
        cin.ignore();

        cout << "What is the grade recieved in the course(As a number 90.0)?";
        cin >> grade;

        dataBase.search(sName,cName,dep,term,grade);

        cout << "Would you like to add more courses to a student? 'y' or 'n'";
        cin >> answer;
        cin.ignore();
      }
  }//***End of user input***

//The removes were able to remove the head but not further
//string sName;
//dataBase.remove(sName);
dataBase.printStudentDB();
cout << "\nSize of linked list is: " << dataBase.length();
}

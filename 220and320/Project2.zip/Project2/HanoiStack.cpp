#include "HanoiStack.h"
#include<iostream>
#include<stdio.h>
#include<string>
using namespace std;

//Default constructor
HanoiStack::HanoiStack()
{
  head = NULL;
}


//Destructor
HanoiStack::~HanoiStack()
{
  /*Disk* tempPtr = head;
    while (tempPtr) {
      tempPtr = tempPtr->next;
      delete head;
      head = tempPtr;
    }*/
}

int HanoiStack::winCheck()
{
  Disk* tempPtr = head;
  int count = 0;

    while(tempPtr != NULL)
    {
      tempPtr = tempPtr->next;
      count++;
    }
  return count;
}

//Checks to see what value is on top
int HanoiStack::peak()
{
  Disk* tempPtr = head;
  return head->size;
}

//Checks to see if stack is empty returns boolean
bool HanoiStack::isEmpty(HanoiStack &s)
{
  if(head == NULL)
  {
    return true;
  }
  else
  {
    return false;
  }
}

//Inserts nodes into stack
void HanoiStack::push(int* size)
{
  Disk* newNode = new Disk;
  newNode->size = *(size);

   //Makes sure theres a head if not it makes one
  if(head == NULL)
  {
    head = newNode;
    return;
  }
  newNode->next = head;
  head = newNode;
}

//Removes the last element put into the stack
int& HanoiStack::pop()
{
  Disk* curr = head;
  Disk* prev = head;

  if(curr ==  NULL)
  {
    cout << "Empty";
    return curr->size;
  }

  if(head->next != NULL)
  {
    prev = head;
    curr = head->next;
    head = curr;
    return prev->size;
  }

  if(head->next == NULL)
  {
    Disk* tempPtr = head;
    head = NULL;
    return tempPtr->size;
  }

}

HanoiStack operator+=(HanoiStack &s1, HanoiStack &s2)
{
  if(s1.isEmpty(s1) == true && s2.isEmpty(s2) == true)
  {
    return s2;
  }

  else if(s1.isEmpty(s1) ==true)
  {
    return s1;
  }
  
  else if(s2.isEmpty(s2) ==true)
  {
    s2.push(&s1.pop());
    return s2;
  }

  else if(s1.peak() > s2.peak())
  {
    cout << "\nMove is invalid." << "\n";
    return s2;
  }
  else
  {
   s2.push(&s1.pop());
   return s2;
  }
}

ostream& operator<<(ostream &oStream,HanoiStack &s)
{
  return s.printStacks(oStream);
}

//Prints list
ostream& HanoiStack::printStacks(ostream& oStream)
{
  Disk* tempPtr = head;
    while(tempPtr != NULL)
    {
      oStream << "Disk:" << tempPtr->size << "\n";
      tempPtr = tempPtr->next;
    }
    return oStream;
}

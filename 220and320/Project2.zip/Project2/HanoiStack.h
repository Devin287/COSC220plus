#ifndef HANOISTACK_H
#define HANOISTACK_H
#include <iostream>
using namespace std;

class HanoiStack
{
  struct Disk{
    int size;
    Disk* next;
  };
Disk* head;

private:
  friend ostream& operator<<(ostream &oStream,HanoiStack &s);
  friend HanoiStack operator+=(HanoiStack &s1, HanoiStack &s2);
  int peak();
  bool isEmpty(HanoiStack &s);

  public:
    HanoiStack();
    ~HanoiStack();
    void push(int*);
    int& pop();
    ostream& printStacks(ostream&);
    int winCheck();
};

#endif

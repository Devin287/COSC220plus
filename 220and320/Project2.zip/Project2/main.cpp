/*
 * Name:Devin schmidt
 * Course: COSC-220
 * Project 2
 */
#include "HanoiStack.h"
#include<iostream>
#include<fstream>
using namespace std;

//Method to show the solution if user chooses
void SolveHanoi(int n, char start, char end, char tmp)
{
  if(n >= 1)
  {
    SolveHanoi(n-1, start, tmp, end);
    printf("Move disc %d from %c to %c.\n",n,start,end);
    SolveHanoi(n-1,tmp,end,start);
  }
}

//Main
int main(int argc, char** argv)
{
  //Creating neccesary data for game
  HanoiStack s1;
  HanoiStack s2;
  HanoiStack s3;
  int diskSizeU;
  int* diskSize;
  bool running = true;
  char answer;
  char sFrom;
  char sTo;
  int counter = 0;

  //Asking user how many disks they would like in their game
  //And allowing them to choose
  cout << "How many disks do you want (2 to 10)? " << "\n";
  cin >> diskSizeU;

    while(diskSizeU < 2 || diskSizeU > 10)
    {
      cout << "Invalid input use 2 through 10. " << "\n";
      cin >> diskSizeU;
    }
  diskSize = &diskSizeU;
  int fill = diskSizeU;
  //When user chooses how many disks a stack gets filled with that many
        for(int i = fill; i > 0; i--)
        {
          s1.push(&fill);
          fill--;
        }

  //Option for the user to see the optimal solution for how many disks they have
  cout << "Would you like to see the optimal solution?\n";
  cin >> answer;
  while(answer != 'y' && answer != 'n')
  {
      cin >> answer;
  }
  if(answer == 'y')
  {
    SolveHanoi(diskSizeU, 'a','b','c');
  }

 //Game loop to kee p the game running until user exits
  while(running == true){

    //Prints the stacks
    cout << "\nStack a:\n" << s1 << "\nStack b:\n" << s2 << "\nStack c:\n" << s3;

    //Asking the user which disk they would like to move from which stacks
    cout << "Which stack would you like to move from?('a','b','c')";
      cin >> sFrom;
      //Validating that their input is allowed
      while(sFrom != 'a' && sFrom != 'b' && sFrom != 'c')
      {
        cout << "Ivalid input. Please enter('a','b','c')";
        cin >>sFrom;
      }

    cout << "Which stack would you like to move it to?('a','b','c')";
      cin >> sTo;
      //Validating their input is allowed
      while(sTo != 'a' && sTo != 'b' && sTo != 'c')
      {
        cout << "Ivalid input. Please enter('a','b','c')";
        cin >>sTo;
      }

    //The inputs are compared to all possible combinations
    //To correctly choose which stack the disk get moved to
    if(sFrom == 'a' && sTo == 'b')
    {
      s1+=s2;
    }
    if(sFrom == 'a' && sTo == 'c')
    {
      s1+=s3;
    }
    if(sFrom == 'b' && sTo == 'c')
    {
      s2+=s3;
    }
    if(sFrom == 'b' && sTo == 'a')
    {
      s2+=s1;
    }
    if(sFrom == 'c' && sTo == 'b')
    {
      s3+=s2;
    }
    if(sFrom == 'c' && sTo == 'a')
    {
      s3+=s1;
    }

    //Counter increments after a move to count the moves and is printed
    // when user has won
    counter++;

    //Checks to see is the user has won after each move is so end game
    if(s2.winCheck() == diskSizeU)
    {
      cout << "Congrats! You won!" << " It took you " << counter << " moves.";
      running = false;
    }
    if(s3.winCheck() == diskSizeU)
    {
      cout << "Congrats! You won!" << " It took you " << counter << " moves.";
      running = false;
    }

      //After each move the user is asked if they would like to exit
      cout << "\nWould you like to exit?('y' or 'n')";
      cin >> answer;
          while(answer != 'y' && answer != 'n')
          {
              cin >> answer;
          }
              if(answer == 'y')
              {
                running = false;
              }
  }
  return 0;
}

#include "SUList.h"
#include "payroll.h"

#include <iostream>

// default constructor
// @author Cody
template<class T>
SUList<T>::SUList()
{
  head=nullptr;
  tail=nullptr;
}

// deconstructor
// @author Cody
template<class T>
SUList<T>::~SUList()
{
  ListNode* temp = head;

  while(temp){
    temp = temp->next;
    delete head;
    head = temp;
  }
};

//@author Devin
// Copy constructor
template<class T>
SUList<T>::SUList(const SUList<T> &l)
{

//Case to test if list is empty
if(l.head == nullptr){
  head = nullptr;
  tail = nullptr;
}

  head = new ListNode;
  head->data = l.head->data;
  head->prev = l.head->prev;

  ListNode* currList = l.head;
  ListNode* currCopy = head;

  currList = currList->next;

  while(currList != nullptr)
  {
    ListNode* prev = currCopy;
    currCopy->next = new ListNode;
    currCopy = currCopy->next;
    currCopy->prev = prev;
    currCopy->data = currList->data;
    currList = currList->next;
  }
}

//@author Devin and Cody
template<class T>
SUList<T>& SUList<T>::operator=(const SUList<T> &SUList)
{
  ListNode* temp = head;

  //Deletes old list
  while(temp != nullptr)
  {
    temp = temp->next;
    delete head;
    head = temp;
  }

//Creates new list with same values
  if(this != &SUList)
  {
    if(head == nullptr)
    {
      head = SUList.head;
      head->data = SUList.head->data;
    }

    ListNode* currList = SUList.head;
    ListNode* currCopy = head;


    currList = currList->next;

    while(currList != nullptr)
    {
      ListNode* prev = currCopy;
      currCopy->next = currList;
      currCopy = currCopy->next;
      currCopy->prev = prev;
      currCopy->data = currList->data;
      currList = currList->next;
    }
  }
  return *this;
}

// Puts on the front of the List
// @author Devin and Cody
template<class T>
void SUList<T>::putFront(const T& p)
{
  ListNode* node = new ListNode;
  node->data=p;
  node->prev = nullptr;
  node->next = nullptr;

 //Case testing empty list
  if(head == nullptr)
  {
    head = node;
    head->prev = node;
    tail = node;
    tail->prev = node;
    return;
  }

  node->next = head;
  head->prev = node;
  head = node;
}

// Puts on back of linked list
template<class T>
void SUList<T>::putBack(const T& p)
{
  ListNode* nNode = new ListNode;
  nNode->data=p;
  nNode->prev = nullptr;
  nNode->next = nullptr;

  if(head == nullptr)
  {
    head = nNode;
    head->prev = nNode;
    tail = nNode;
    tail->prev = nNode;
    return;
  }

  tail->next = nNode;
  nNode->prev = tail;
  tail = nNode;
};


// check to see if it is doubly linked list
//@author Devin and Cody
template<class T>
T SUList<T>::getBack()
{
  ListNode* back = tail;

  if(back == nullptr)
  {
      std::cout<<"The stack is empty\n";
      return back->data;
  }

  if(tail->prev != nullptr)
  {
    tail = back->prev;
    tail->next = nullptr;
    delete back;
    return tail->data;
  }

  if(tail->next == nullptr)
  {
    ListNode* temp = tail;
    tail = nullptr;
    return temp->data;
  }
  return head->data;
}

//Returns the front back of list and deltes it
//@author Devin and Cody
template<class T>
T SUList<T>::getFront()
{
  ListNode* last = head;

//If the list is empty
  if(head == nullptr)
  {
      std::cout<<"The stack is empty\n";
      return head->data;
  }

//If there is only more than one element element after current element
  if(head->next != nullptr)
  {
    head = head->next;
    head->prev = nullptr;
    delete last;
    return head->data;
  }

//If there is only one element after current element
  if(head->next == nullptr)
  {
    ListNode* temp = head;
    head = nullptr;
    return temp->data;
  }
  return head->data;
}

//Ostream overload to print lists
//@author Devin and Cody
template<class T>
std::ostream& operator<<(std::ostream &oStream, SUList<T> &s)
{
  return s.display(oStream);
}

//Ostream overload to print lists
//@author Devin and Cody
template<class T>
std::ostream& SUList<T>::display(std::ostream& oStream)
{
  ListNode* temp = head;
  while(temp != nullptr)
  {
    oStream << temp->data << "\n";
    temp = temp->next;
  }
  return oStream;
}

//Checks list for a value
//@author Devin and Cody
template<class T>
bool SUList<T>::contains(const T &d)
{
  ListNode* temp = head;

  while(temp != NULL)
  {
    if(d == temp->data)
    {
      return true;
    }
    temp = temp->next;
  }
  return false;
}

// gets the size of the list
// @author Cody
template<class T>
int SUList<T>::size()const{

  ListNode* len = head;
  int size = 0;
  while(len != NULL)
  {

    len = len->next;
    size++;
  }
  return size;
}

#ifndef SULIST_H
#define SULIST_H
#include <iostream>

template <class DataType>
  class SUList
  {
    struct ListNode
    {
      DataType data;
      ListNode* next;
      ListNode* prev;
    };

    ListNode* head;
    ListNode* tail;
  public:
    SUList();
    SUList(const SUList&);
    ~SUList();
    DataType getFront();
    DataType getBack();
    void putFront(const DataType&);
    void putBack(const DataType&);
    int size() const;
    bool contains(const DataType&);
    SUList<DataType>& operator=(const SUList<DataType>&);

    std::ostream& display(std::ostream&);
    template <class J>
    friend std::ostream& operator<<(std::ostream& oStream,SUList<J> &s);
  };

#endif

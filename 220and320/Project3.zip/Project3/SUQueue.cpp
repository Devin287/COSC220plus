#include "SUQueue.h"
#include "SUStack.h"
#include "SUList.h"
#include "payroll.h"
#include <iostream>


//@author Devin
//Default constructor
template<class T>
SUQueueList<T>::SUQueueList()
{
  SUList<T> list;
}

//@author Devin
//Destructor
template<class T>
SUQueueList<T>::~SUQueueList()
{

}

//@author Devin
//Overloaded operator
template<class T>
SUQueueList<T>& SUQueueList<T>::operator=(const SUQueueList<T> &SUList)
{
  list = SUList;
  return *this;
}

//@author Devin
//Copy Constructor
template<class T>
SUQueueList<T>::SUQueueList(const SUQueueList<T> &list)
{
  list(list);
}

//@author Cody & Devin
//Adds element to queue
template<class T>
void SUQueueList<T>::enqueue(const T& t)
{
  list.putBack(t);

}

//Puts element in the front of listCopy
template<class T>
void SUQueueList<T>::dequeue(T& t)
{
  t = list.getFront();
}

//Prints list
//Prints queue
template<class T>
void SUQueueList<T>::printQueue()
{
  std:: cout << list;
}


//@author Devin
//Checks size of queue
template<class T>
int SUQueueList<T>::size() const
{
  return list.size();
}

//@author Devin
//Checks if queue is empty
template<class T>
bool SUQueueList<T>::isEmpty() const
{
  int t = list.size();
  if(t == 0);
  {
    std::cout << "The list is empty.";
      return 1;
  }
      return 0;

}

//COntrucor for queue
template<class T>
SUQueueArr<T>::SUQueueArr()
{
  capacity = 10;
  front = 0;
  rear = 0;
  arr = new T[capacity];
}

//Copys elements from queue to another
template<class T>
SUQueueArr<T>::SUQueueArr(const SUQueueArr<T> &sa)
{
  capacity = sa.capacity;
  rear = sa.rear;
  front = sa.front;
  arr = new T[capacity];

  for(int i= front; i < capacity; i++)
  {
    arr[i] = sa.arr[i];
  }
}

// destructor for SUStackArr
template<class T>
SUQueueArr<T>::~SUQueueArr()
{
  delete [] arr;
}

// uses capacity to check the size of the SUStackArr
template<class T>
int SUQueueArr<T>::size()const
{
  int size = 0;
  for(int i = front; i < rear; i++)
  {
    size ++;
  }
  return size;
}

//uses top to see if the SUStackArr is empty
template<class T>
bool SUQueueArr<T>::isEmpty()const
{
  if(front == -1)
  {
    return true;
  }
  return false;
}

//Adds element to queue
template<class T>
void SUQueueArr<T>::enqueue(const T& p)
{
  if(capacity == rear)
  {
    capacity++;
  }
    arr[rear] = p;
    rear++;
}

//Removes element from queue
template<class T>
void SUQueueArr<T>::dequeue(T &p)
{
    for(int i = 0; i < rear - 1; i++)
    {
      arr[i] = arr[i + 1];
    }
    rear--;
}

// prints the SUStackArr top down using a for loop
template<class T>
void SUQueueArr<T>::printQueue()const
{
  if(rear == front)
  {
    std::cout <<"Empty.";
  }
  for(int i = front; i < rear; i++)
  {
      std::cout<<arr[i];
      if(front == i)
      {
        std::cout<<"<-top";
      }
      std::cout<<std::endl;
  }
}

//Copys elements from one list to another after deletion
template<class T>
SUQueueArr<T>& SUQueueArr<T>::operator=(const SUQueueArr<T> &SUQueueArr)
{
  delete [] arr;

  capacity = SUQueueArr.capacity;
  rear = SUQueueArr.rear;
  front = SUQueueArr.front;
  arr = new T[capacity];

  for(int i= front; i < capacity; i++)
  {
    arr[i] = SUQueueArr.arr[i];
  }
  return *this;
}

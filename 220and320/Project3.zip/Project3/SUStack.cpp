#include "SUStack.h"
#include "SUList.h"
#include "payroll.h"
#include <iostream>


//@author Devin
//Default constructor
template<class T>
SUStackList<T>::SUStackList()
{
  SUList<T> list;
}

//@author Devin
//Destructor
template<class T>
SUStackList<T>::~SUStackList()
{
  //delete list;
}

//@author Devin
//Overloaded operator
template<class T>
SUStackList<T>& SUStackList<T>::operator=(const SUStackList<T> &s)
{
  list = s.list;
  return *this;
}

//@author Devin
//Copy Constructor
template<class T>
SUStackList<T>::SUStackList(const SUStackList<T> &l)
{
  list = l.list;
}

//@author Cody & Devin
template<class T>
void SUStackList<T>::push(const T& t)
{
  list.putFront(t);

}

//Puts element in the front of listCopy
template<class T>
void SUStackList<T>::pop(T& t)
{
  t = list.getFront();
}

//Prints list
template<class T>
void SUStackList<T>::printStack()
{
  std:: cout << list;
}

//@author Devin
//CHecks the size of stack
template<class T>
int SUStackList<T>::size() const
{
  return list.size();
}

//@author Devin
//Checks if stack is empty
template<class T>
bool SUStackList<T>::isEmpty() const
{
  int t = list.size();
  if(t == 0);
  {
    std::cout << "The list is empty.";
      return 1;
  }
      return 0;

}


//Default constructor for SUStackArr
template<class T>
SUStackArr<T>::SUStackArr()
{
  capacity = 10;
  top = -1;
  arr = new T[capacity];
}

//Copys Stacks
template<class T>
SUStackArr<T>::SUStackArr(const SUStackArr<T> &sa)
{
  capacity = sa.capacity;
  top = sa.top;
  arr = new T[capacity];

  for(int i= 0; i < capacity; i++)
  {
    arr[i] = sa.arr[i];
  }
}

//Destructor for SUStackArr
template<class T>
SUStackArr<T>::~SUStackArr()
{
  delete [] arr;
}

//Uses capacity to check the size of the SUStackArr
template<class T>
int SUStackArr<T>::size()const
{
  int size = 0;
  for(int i = 0; i < top+1; i++)
  {
    size ++;
  }
  return size;
}

//Uses top to see if the SUStackArr is empty
template<class T>
bool SUStackArr<T>::isEmpty()const
{
  if(top == -1)
  {
    return true;
  }
  return false;
}

//Adds element to Stack
template<class T>
void SUStackArr<T>::push(const T& p)
{
  if(top < capacity -1)
  {
    arr[++top] = p;
  }else
  {
    std::cout<<"Stack Overflow\n";
  }
}

//Removes element from stack
template<class T>
void SUStackArr<T>::pop(T &p)
{
  if(top>0)
  {
    capacity -= 1;
    arr[--top];
  }
}

//Prints the SUStackArr top down using a for loop
template<class T>
void SUStackArr<T>::printStack()const
{
  for(int i = top; i >=0; i--)
  {
      std::cout<<arr[i];
      if(top == i)
      {
        std::cout<<"<-top";
      }
      std::cout<<std::endl;
  }
}

//Deletes old list and assigns values to new list
template<class T>
SUStackArr<T>& SUStackArr<T>::operator=(const SUStackArr<T> &SUStackArr)
{
  delete [] arr;

  capacity = SUStackArr.capacity;
  top = SUStackArr.top;
  arr = new T[capacity];

  for(int i= 0; i < capacity; i++)
  {
    arr[i] = SUStackArr.arr[i];
  }
  return *this;
}

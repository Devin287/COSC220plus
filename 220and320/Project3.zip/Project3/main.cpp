#include "SUList.cpp"
#include "SUStack.cpp"
#include "SUQueue.cpp"
#include "SUList.h"
#include "SUQueue.h"
#include "SUStack.h"
#include "payroll.h"
#include <iostream>

int main()
{

  //Declaring the lists, stacks, and queues
  int temp;
  SUList<int> myList;
  SUList<PayRoll> pList;

  SUStackArr<int> iStackArr;
  SUStackArr<PayRoll> pStackArr;
  SUStackList<int> iStackList;
  SUStackList<PayRoll> pStackList;

  SUQueueArr<int> iQueueArr;
  SUQueueArr<PayRoll> pQueueArr;
  SUQueueList<int> iQueueList;
  SUQueueList<PayRoll> pQueueList;

  /**
   * Test for SUList ints
   */
  std::cout << "SUList integers..\n";
  myList.putFront(4);
  myList.putFront(3);
  myList.putFront(2);
  myList.putFront(1);
  myList.putBack(5);
  myList.putBack(6);
  myList.getFront();
  myList.getBack();

  std::cout << myList;
  std::cout << "++++++++++++\n";

  SUList<int> myListCop;
  myListCop = myList;
  std::cout << myListCop;

//Testing True case for conatins method.
  if(myList.contains(2) == 1)
  {
    std::cout << "\nSUList does contain 2.\n";
  }else
  {
    std::cout << "SUList does not contain 2.\n";
  }

//Testing False case for conatins method.
  if(myList.contains(12) == 1)
  {
    std::cout << "\nSUList does contain 12.\n";
  }else
  {
    std::cout << "Your list does not contain 12.\n";
  }

  std::cout << "\n++++++++++++\n";

  /**
   * Test for SUList PayRolls
   */
   std::cout << "\nSUList PayRolls..\n";
   pList.putFront(PayRoll("Bob",20, 35));
   pList.putFront(PayRoll("Alice",10, 35));
   pList.putBack(PayRoll("Charlie",20, 35));
   pList.putBack(PayRoll("Diana",10, 35));
   pList.putFront(PayRoll("Eve",30, 35));

   std::cout << pList;
   std::cout << "++++++++++++\n";

   /**
    * Test for SUStack ints
    */
   std::cout << "SUStackArr integers..\n";
   iStackArr.push(4);
   iStackArr.push(3);
   iStackArr.push(2);
   iStackArr.push(1);
   iStackArr.pop(temp);

   iStackArr.printStack();
   std::cout << "\nSUStackArr does/doesn't contain: " << iStackArr.isEmpty();
   std::cout << "\n++++++++++++\n";

   /**
    * Test for SUStack PayRolls
    */
    std::cout << "\nSUStack PayRolls..\n";
    PayRoll temp2;
    pStackArr.push(PayRoll("Bob",20, 35));
    pStackArr.push(PayRoll("Alice",10, 35));
    pStackArr.push(PayRoll("Charlie",20, 35));
    pStackArr.pop(temp2);
    pStackArr.push(PayRoll("Eve",30, 35));

    pStackArr.printStack();
    std::cout << "++++++++++++\n";

    /**
     * Test for SUStackList integers
     */

     std::cout << "SUStackList integers..\n";
     iStackList.push(4);
     iStackList.push(3);
     iStackList.push(2);
     iStackList.push(1);
     iStackList.pop(temp);

     iStackList.printStack();
     std::cout << "++++++++++++\n";

     SUStackList<int>iStackListCop(iStackList);
     iStackListCop.printStack();

     /**
      * Test for SUStackList PayRolls
      */
       std::cout << "\nSUStackList PayRolls..\n";
       pStackList.push(PayRoll("Bob",20, 35));
       pStackList.push(PayRoll("Alice",10, 35));
       pStackList.push(PayRoll("Charlie",20, 35));
       pStackList.pop(temp2);
       pStackList.push(PayRoll("Eve",30, 35));

       pStackList.printStack();
       std::cout << "++++++++++++\n";


      /**
       * Test for SUQueue ints
       */
      std::cout << "SUQueue integers..\n";
      iQueueArr.enqueue(4);
      iQueueArr.enqueue(3);
      iQueueArr.enqueue(2);
      iQueueArr.enqueue(1);
      iQueueArr.dequeue(temp);

      iQueueArr.printQueue();
      std::cout << "++++++++++++\n";

      /**
       * Test for SUQueue PayRolls
       */
       std::cout << "SUQueue PayRolls..\n";
       pQueueArr.enqueue(PayRoll("Bob",20, 35));
       pQueueArr.enqueue(PayRoll("Alice",10, 35));
       pQueueArr.enqueue(PayRoll("Charlie",20, 35));
       pQueueArr.dequeue(temp2);
       pQueueArr.enqueue(PayRoll("Eve",30, 35));

       pQueueArr.printQueue();
       std::cout << "++++++++++++\n";


       /**
        * Test for SUQueueList integers
        */
        std::cout << "SUQueueList integers..\n";
        iQueueList.enqueue(4);
        iQueueList.enqueue(3);
        iQueueList.enqueue(2);
        iQueueList.enqueue(1);
        iQueueList.dequeue(temp);

        iQueueList.printQueue();
        std::cout << "++++++++++++\n";

        SUStackList<int>iStackListCopp;
        iStackListCopp = iStackList;
        iStackListCopp.printStack();

         /**
          * Test for SUQueueList PayRolls
          */
          std::cout << "SUQueueList PayRolls..\n";
          pQueueList.enqueue(PayRoll("Bob",20, 35));
          pQueueList.enqueue(PayRoll("Alice",10, 35));
          pQueueList.enqueue(PayRoll("Charlie",20, 35));
          pQueueList.dequeue(temp2);
          pQueueList.enqueue(PayRoll("Eve",30, 35));

          pQueueList.printQueue();
          std::cout << "++++++++++++\n";
}

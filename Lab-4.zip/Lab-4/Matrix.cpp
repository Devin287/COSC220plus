#include <iostream>
#include "Matrix.h"

Matrix::Matrix(long rowSize, long colSize){
  setRowSize(rowSize);
  setColSize(colSize);

  arr = new long*[rowSize];
  for(long row =0; row < rowSize; row++){
    arr[row] = new long[rowSize];
  }
}
//
Matrix::Matrix(const Matrix& matrix){
  arr = new long*[matrix.rowSize];
  rowSize = matrix.rowSize;
  colSize = matrix.colSize;

  for(long i = 0; i < matrix.rowSize; i++){
    arr[i] = new long[matrix.colSize];
  }

  for(long i = 0; i < matrix.rowSize; i++){
    for(long j = 0; j < matrix.colSize; j++){
      arr[i][j] = matrix.arr[i][j];
    }
  }
}

Matrix& Matrix::operator=(const Matrix& matrix){
  if(rowSize != matrix.rowSize || colSize != matrix.colSize){
    std::cout << "\nArray must be the same size to prevent memory complications.\n";
    return *this;
  }

  arr = new long*[matrix.rowSize];
  rowSize = matrix.rowSize;
  colSize = matrix.colSize;

  for(long i = 0; i < matrix.rowSize; i++){
    arr[i] = new long[matrix.colSize];
  }

  for(long i = 0; i < matrix.rowSize; i++){
    for(long j = 0; j < matrix.colSize; j++){
      arr[i][j] = matrix.arr[i][j];
    }
  }
  return *this;
}

Matrix::~Matrix(){
  for(long i = 0; i < getRowSize(); i++){
    delete [] arr[i];
  }
  delete [] arr;
}

long Matrix::getRowSize(){
  return rowSize;
}

void Matrix::setRowSize(long rowSize){
  this->rowSize = rowSize;
}

long Matrix::getColSize(){
  return colSize;
}

void Matrix::setColSize(long colSize){
  this->colSize = colSize;
}

void Matrix::printMatrix(){
  for(long row = 0; row < getRowSize(); row++){
    for(long col = 0; col < getColSize(); col++){
      std::cout << " " << arr[row][col];
    }
    std::cout << std::endl;
  }
}

void Matrix::fillMatrix(long col, long row, long data){
  for(long row = 0; row < getRowSize(); row++){
    for(long col = 0; col < getColSize(); col++){
      arr[row][col] = data++;
    }
  }
}

Matrix operator+(Matrix& b){

}

Matrix operator-(Matrix& b){

}

Matrix operator*(Matrix& b){
  /*if(rowSize != b.getRowSize()){
    std::cout << "\nInvalid multiplication, rows and columns must be the same size.\n";
    return b;
  }
  Matrix matrixSum(b.getRowSize(),b.getColSize());

  for(long i = 0; i < arr.getRowSize(); i++){
    for(long j = 0; j < b.getColSize(); j++){
      for(long g = 0; g < getColSize(); g++){
        matrixSum[i][j] += arr[i][g] * b[g][j];
      }
    }
  }
  return matrixSum;*/
}

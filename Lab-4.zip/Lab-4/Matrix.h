#ifndef MATRIX_H
#define MATRIX_H
#include<iostream>

class Matrix{
private:
  long** arr;
  long rowSize;
  long colSize;

public:
  Matrix(long,long);
  Matrix(const Matrix&);
  Matrix& operator=(const Matrix&);
  ~Matrix();
  long getRowSize();
  void setRowSize(long);
  long getColSize();
  void setColSize(long);
  void printMatrix();
  void fillMatrix(long, long, long);
  Matrix operator+(Matrix&);
  Matrix operator-(Matrix&);
  Matrix operator*(Matrix&);
};
#endif

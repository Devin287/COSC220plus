#include <iostream>
#include "Matrix.h"
/*
 *Devin Schmidt
 *COSC-320
 *Lab-4
 */
int main(){

  Matrix matrix(3,3);
  matrix.fillMatrix(0,0,1);
  matrix.fillMatrix(1,0,1);
  matrix.printMatrix();

  std::cout << "\n";

  Matrix copyMatrix(matrix);
  copyMatrix.printMatrix();

  std::cout << "\n";

  Matrix assignmentMatrix = matrix;
  assignmentMatrix.printMatrix();

  return 0;
}

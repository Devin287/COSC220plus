#include "Hash.h"
#include <iostream>
#ifndef HASH_H
#define HASH_H

class Hash{
private:
  struct ListNode{
  };
};

#endif

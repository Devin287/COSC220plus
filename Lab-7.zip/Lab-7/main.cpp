#include "Hash.h"
#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
/*
 *Devin Schmidt
 *COSC-320
 *Lab-7
 */

//to hash a number
 size_t h(size_t x){
   size_t w = 32;
   size_t p = 10;
   size_t a = 3628253133;

   size_t ax = a*x;
   printf("a*x = %#ld\n", ax);

   //const of 1 created because of complication of 1 being an int of 4 bytes when shifting bits
   const size_t ONE = 1;

   //Calculates 2^w by shifting bits
   size_t twoTow = ONE<<w;
   printf("2^w = %#ld\n", twoTow);

   //Performs interger division of a % 2^w by shifting bits
   size_t axModW = ax & ((ONE<<w)-ONE);
   printf("ax % 2^w = %#ld\n", axModW);

   size_t hash = axModW >> (w-p);
    return hash;
 }

//to hash a string argument
 size_t s(char x[], size_t n){
   size_t w = 32;
   size_t p = 10;
   size_t a = 3628253133;
   size_t strSize = 0;

   for(size_t i = 0; i < n; i++){
    strSize =  size_t(x[i]) + strSize;
   }

   size_t ax = a*strSize;
   //const of 1 created because of complication of 1 being an int of 4 bytes when shifting bits
   const size_t ONE = 1;

   size_t twoTow = ONE<<w;
   size_t axModW = ax & ((ONE<<w)-ONE);


   size_t hash = axModW >> (w-p);
    return hash;
 }

 //Dosnt do anything different
 //to hash a string argument but will use a hex value instead
  size_t s2(char x[], size_t n){
    size_t w = 32;
    size_t p = 10;
    size_t a = 3628253133;
    size_t strSize = 0;

    for(size_t i = 0; i < n; i++){
     strSize =  size_t(x[i]) + strSize;
    }
    size_t ax = a*strSize;
    //const of 1 created because of complication of 1 being an int of 4 bytes when shifting bits
    const size_t ONE = 1;

    size_t twoTow = ONE<<w;
    size_t axModW = ax & ((ONE<<w)-ONE);


    size_t hash = axModW >> (w-p);
     return hash;
  }

  //to convert a size_t to hex
  void convertSize_t(size_t x){
    std::cout << std::hex << x;

    //x = std::hex;
    char c[2];
    for(int i = 0; i < 2; i++){
      //c[i] = std::hex(x);
    }
  }


int main(){

 std::cout << "\nTesting individual calculations of hash function and printing hash...";
 size_t x = 0;
 std::cout << "\nEnter a number.";
 std::cin >> x;
 printf("h(x) = %ld\n", h(x));

 std::cout << "\nHashing a string...\n";
 char str[5] = {'D','e','v','i','n'};
 std::cout << "The hash value is " << s(str,5) << std::endl;

 std::cout << "\nHashing a string using function s2...\n";
 char str2[5] = {'D','e','v','i','n'};
 std::cout << "The hash value is " << s(str2,5) << std::endl;

 std::cout << "\nTesting size_t conversion to hex..\n";
 convertSize_t(x);


  return 0;
}

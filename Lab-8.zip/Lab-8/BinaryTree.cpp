#include "BinaryTree.h"
#include<iostream>

BinaryTree::BinaryTree(){
  root = NULL;
}

BinaryTree::~BinaryTree(){
  delete root;
}

void BinaryTree::insert(BinaryTree* T, int x)
{
  TreeNode* newNode = new TreeNode;
  newNode->key = x;
  newNode->left = NULL;
  newNode->right = NULL;

  //Makes sure theres a head if not it makes one
  if(T->root == NULL){
    T->root = newNode;
    return;
  }
  TreeNode* curr = T->root;
  TreeNode* prev = NULL;

  //loops through tree and inserts value in correct position
  while(curr)
  {
    prev = curr;
    if(newNode->key < curr->key)
    {
      curr = curr->left;
    }
    else{
      curr = curr->right;
    }
  }
  newNode->parent = prev;
  if(newNode->key < prev->key){
    prev->left = newNode;
  }
  else{
    prev->right = newNode;
  }
}

bool BinaryTree::search(BinaryTree* T,int x){
  TreeNode* curr = T->root;

  if(curr == NULL || curr->key == x){
    return true;
  }
  while(curr != NULL && x != curr->key){

      if(x < curr->key){
        curr = curr->left;
      }
      if(curr->key == x){
        return true;
      }
      if(curr->right == NULL){
        return false;
      }
      else{
        curr = curr->right;
      }
  }
  return false;
}

int BinaryTree::minimum(BinaryTree* T){
  TreeNode* curr = T->root;
  while(curr->left != NULL){
    curr = curr->left;
  }
  return curr->key;
}

int BinaryTree::maximum(BinaryTree* T){
  TreeNode* curr = T->root;
  while(curr->right != NULL){
    curr = curr->right;
  }
  return curr->key;
}

int BinaryTree::successor(BinaryTree* T,int x){
  TreeNode* curr = T->root;
  //Searches for node with specific value to start at
  while(curr != NULL && x != curr->key){
      if(curr == NULL || curr->key == x){
        break;
      }
      if(x < curr->key){
        curr = curr->left;
      }
      if(curr->right == NULL){
        break;
      }
      else{
        curr = curr->right;
      }
      if(curr->key == x){
        break;
      }
  }

  //Finds successor
  if(curr->right != NULL){
    while(curr->left != NULL){
      curr = curr->left;
    }
    return curr->key;
  }
  TreeNode* parent = curr->parent;
  while(parent != NULL && curr == parent->right){
    curr = parent;
    parent = parent->parent;
  }
  return parent->key;
}

void BinaryTree::inorder(BinaryTree* T){
  TreeNode* root = T->root;
  inorder(root);
}

void BinaryTree::inorder(TreeNode* root){
  if(!root){
    return;
  }
  inorder(root->left);
  std::cout << root->key << " ";
  inorder(root->right);
}

void BinaryTree::transplant(BinaryTree* T ,TreeNode* u, TreeNode* v){
  if(u->parent == NULL){
    T->root = v;
  }
  else if(u == u->parent->left){
    u->parent->left = v;
  }
  else{
    u->parent->right = v;
  }
  if(v != NULL){
    v->parent = u->parent;
  }
}

void BinaryTree::Delete(BinaryTree* T,int x){
  TreeNode* curr = T->root;
  TreeNode* temp = NULL;
  //Searches for node with specific value to start at
  while(curr != NULL && x != curr->key){
      if(curr == NULL || curr->key == x){
        break;
      }
      if(x < curr->key){
        curr = curr->left;
      }
      if(curr->right == NULL){
        break;
      }
      else{
        curr = curr->right;
      }
      if(curr->key == x){
        break;
      }
  }
  //deletes node
  if(curr->left == NULL){
    transplant(T,curr,curr->right);
  }
  else if(curr->right == NULL){
    transplant(T,curr,curr->left);
  }
  else{
    TreeNode* y = NULL;
    while(curr->left != NULL){
      curr = curr->left;
      y = curr;
    }
      if(y->parent != curr){
        transplant(T,y,y->right);
        y->right = curr->right;
        y->right->parent = y;
      }
      transplant(T,curr,y);
      y->left = curr->left;
      y->left->parent = y;
  }
}

void BinaryTree::print(BinaryTree* T){
  TreeNode* root = T->root;
  print(root);
}

void BinaryTree::print(TreeNode* root){
  if(!root){
    return;
  }
  print(root->right);
  std::cout << root->key << " ";
  print(root->left);
}

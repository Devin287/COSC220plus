#ifndef BINARYTREE_H
#define BINARYTREE_H

class BinaryTree{
  private:
    struct TreeNode {
      int key;
      TreeNode* left;
      TreeNode* right;
      TreeNode* parent;
    };
    TreeNode* root;
  public:
    BinaryTree();
    ~BinaryTree();
    BinaryTree(const BinaryTree&);
    void insert(BinaryTree*, int);
    bool search(BinaryTree*,int);
    int minimum(BinaryTree*);
    int maximum(BinaryTree*);
    int successor(BinaryTree*,int);
    void inorder(BinaryTree*);
    void inorder(TreeNode*);
    void transplant(BinaryTree*,TreeNode*, TreeNode*);
    void Delete(BinaryTree*,int);
    void print(BinaryTree*);
    void print(TreeNode*);
  };
#endif

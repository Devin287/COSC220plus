#include "BinaryTree.h"
#include <iostream>
#include<time.h>
#include<chrono>
using namespace std;

int main(){

  std::cout << "Creating a tree.." << std::endl;
  BinaryTree BT;
  BT.insert(&BT, 20);
  BT.insert(&BT, 30);
  BT.insert(&BT, 10);
  BT.insert(&BT, 5);
  BT.insert(&BT, 40);
  BT.inorder(&BT);

  //Prints the tree backwards(Right, Root, Left)
  std::cout << "\nPrinting tree backwards...\n";
  BT.print(&BT);

  std::cout << "\n\nIf 0, value was not found if 1 value was found.. " <<  BT.search(&BT, 10);
  std::cout << "\nIf 0, value was not found if 1 value was found.. " <<  BT.search(&BT, 1) << std::endl;
  std::cout << "\nThe minimum value in the tree is " << BT.minimum(&BT) << std::endl;
  std::cout << "The maximum value in the tree is " << BT.maximum(&BT) << std::endl;
  std::cout << "The successor to the value 10 is " << BT.successor(&BT, 10) << std::endl;

  std::cout << "\nDeleteing 30 from tree.." << std::endl;
  BT.Delete(&BT, 30);
  BT.Delete(&BT, 10);
  BT.Delete(&BT, 5);
  BT.Delete(&BT, 40);
  //BT.Delete(&BT, 20);
  BT.inorder(&BT);

  std::cout << "\n\n";

  BinaryTree BT30K;

  std::cout << "Testing insertion of 30 thousand elements...\n";
  auto start = chrono::system_clock::now();
  for(int i = 0; i < 30000; i++){
    BT30K.insert(&BT30K, i);
  }
  auto end = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds = end-start;
  time_t end_time = chrono::system_clock::to_time_t(end);
  cout << "finished at " << ctime(&end_time)
  << "elapsed time: " << elapsed_seconds.count() << "s\n";

  std::cout << "Testing search of 30 thousand elements...\n";
  auto start2 = chrono::system_clock::now();
    BT30K.search(&BT30K, 30000);
  auto end2 = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds2 = end2-start2;
  time_t end_time2 = chrono::system_clock::to_time_t(end2);
  cout << "finished at " << ctime(&end_time2)
  << "elapsed time: " << elapsed_seconds2.count() << "s\n";

  std::cout << "Testing deletion of 30 thousand elements...\n";
  auto start3 = chrono::system_clock::now();
  for(int i = 0; i < 30000; i++){
    BT30K.Delete(&BT30K, i);
  }
  auto end3 = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds3 = end3-start3;
  time_t end_time3 = chrono::system_clock::to_time_t(end3);
  cout << "finished at " << ctime(&end_time3)
  << "elapsed time: " << elapsed_seconds3.count() << "s\n";

  std::cout << "\n\n";

  BinaryTree BT40K;

  std::cout << "Testing insertion of 40 thousand elements...\n";
  auto start4 = chrono::system_clock::now();
  for(int i = 0; i < 40000; i++){
    BT40K.insert(&BT40K, i);
  }
  auto end4 = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds4 = end4-start4;
  time_t end_time4 = chrono::system_clock::to_time_t(end4);
  cout << "finished at " << ctime(&end_time4)
  << "elapsed time: " << elapsed_seconds4.count() << "s\n";

  std::cout << "Testing search of 40 thousand elements...\n";
  auto start5 = chrono::system_clock::now();
    BT40K.search(&BT40K, 40000);
  auto end5 = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds5 = end5-start5;
  time_t end_time5 = chrono::system_clock::to_time_t(end5);
  cout << "finished at " << ctime(&end_time5)
  << "elapsed time: " << elapsed_seconds5.count() << "s\n";

  std::cout << "Testing deletion of 40 thousand elements...\n";
  auto start6 = chrono::system_clock::now();
  for(int i = 0; i < 40000; i++){
    BT40K.Delete(&BT40K, i);
  }
  auto end6 = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds6 = end6-start6;
  time_t end_time6 = chrono::system_clock::to_time_t(end6);
  cout << "finished at " << ctime(&end_time6)
  << "elapsed time: " << elapsed_seconds6.count() << "s\n";

  std::cout << "\n\n";

  BinaryTree BT60K;

  std::cout << "Testing insertion of 60 thousand elements...\n";
  auto start7 = chrono::system_clock::now();
  for(int i = 0; i < 120000; i++){
    BT60K.insert(&BT60K, i);
  }
  auto end7 = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds7 = end7-start7;
  time_t end_time7 = chrono::system_clock::to_time_t(end7);
  cout << "finished at " << ctime(&end_time7)
  << "elapsed time: " << elapsed_seconds7.count() << "s\n";

  std::cout << "Testing search of 60 thousand elements...\n";
  auto start8 = chrono::system_clock::now();
    BT60K.search(&BT60K, 120000);
  auto end8 = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds8 = end8-start8;
  time_t end_time8 = chrono::system_clock::to_time_t(end8);
  cout << "finished at " << ctime(&end_time8)
  << "elapsed time: " << elapsed_seconds8.count() << "s\n";

  std::cout << "Testing deletion of 60 thousand elements...\n";
  auto start9 = chrono::system_clock::now();
  for(int i = 0; i < 120000; i++){
    BT60K.Delete(&BT60K, i);
  }
  auto end9 = chrono::system_clock::now();
  chrono::duration<double> elapsed_seconds9 = end9-start9;
  time_t end_time9 = chrono::system_clock::to_time_t(end9);
  cout << "finished at " << ctime(&end_time9)
  << "elapsed time: " << elapsed_seconds9.count() << "s\n";

  return 0;
}

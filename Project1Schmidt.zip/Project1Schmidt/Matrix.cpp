#include <iostream>
#include <cmath>
#include "Matrix.h"

Matrix::Matrix(long rowSize, long colSize){
  setRowSize(rowSize);
  setColSize(colSize);

  arr = new double*[rowSize];
  for(long row =0; row < rowSize; row++){
    arr[row] = new double[rowSize];
  }
}
//
Matrix::Matrix(const Matrix& matrix){
  arr = new double*[matrix.rowSize];
  rowSize = matrix.rowSize;
  colSize = matrix.colSize;

  for(long i = 0; i < matrix.rowSize; i++){
    arr[i] = new double[matrix.colSize];
  }

  for(long i = 0; i < matrix.rowSize; i++){
    for(long j = 0; j < matrix.colSize; j++){
      arr[i][j] = matrix.arr[i][j];
    }
  }
}

Matrix& Matrix::operator=(const Matrix& matrix){
  if(rowSize != matrix.rowSize || colSize != matrix.colSize){
    std::cout << "\nArray must be the same size to prevent memory complications.\n";
    return *this;
  }

  rowSize = matrix.rowSize;
  colSize = matrix.colSize;

  for(long i = 0; i < matrix.rowSize; i++){
    for(long j = 0; j < matrix.colSize; j++){
      arr[i][j] = matrix.arr[i][j];
    }
  }
  return *this;
}

Matrix::~Matrix(){
  for(long i = 0; i < getRowSize(); i++){
    delete [] arr[i];
  }
  delete [] arr;
}

long Matrix::getRowSize(){
  return rowSize;
}

void Matrix::setRowSize(long rowSize){
  this->rowSize = rowSize;
}

long Matrix::getColSize(){
  return colSize;
}

void Matrix::setColSize(long colSize){
  this->colSize = colSize;
}

void Matrix::printMatrix(){
  for(long row = 0; row < getRowSize(); row++){
    for(long col = 0; col < getColSize(); col++){
      std::cout << " " << arr[row][col];
    }
    std::cout << std::endl;
  }
}

void Matrix::fillMatrix(long col, long row, long data){
  for(long row = 0; row < getRowSize(); row++){
    for(long col = 0; col < getColSize(); col++){
      arr[row][col] = data++;
    }
  }
}

//Fills a matrix symmetrically
void Matrix::fillMatrixSymmetrically(Matrix& matrix){
  for(long row = 0; row < getRowSize(); row++){
    for(long col = 0; col < getColSize(); col++){
      if(row == 0 && col == 0){
        matrix.arr[row][col] = 1;
      }
      if(row == 0 && col == 1){
        matrix.arr[row][col] = 2;
      }
      if(row == 0 && col == 2){
        matrix.arr[row][col] = 3;
      }
      if(row == 1 && col == 0){
        matrix.arr[row][col] = 2;
      }
      if(row == 1 && col == 1){
        matrix.arr[row][col] = 1;
      }
      if(row == 1 && col == 2){
        matrix.arr[row][col] = 4;
      }
      if(row == 2 && col == 0){
        matrix.arr[row][col] = 3;
      }
      if(row == 2 && col == 1){
        matrix.arr[row][col] = 4;
      }
      if(row == 2 && col == 2){
        matrix.arr[row][col] = 3;
      }
    }
  }
}

void Matrix::fillMatrixUser(Matrix& matrix){
  for(long row = 0; row < getRowSize(); row++){
    for(long col = 0; col < getColSize(); col++){
      std::cin >> matrix.arr[row][col];
    }
  }
}

Matrix Matrix::operator+(Matrix& b){
  Matrix matrixSum(b.getRowSize(),b.getColSize());

  for(int i = 0; i < rowSize; i++){
    for(int j = 0; j < colSize; j++){
      matrixSum.arr[i][j] = arr[i][j] + b.arr[i][j];
    }
  }
  return matrixSum;
}

Matrix Matrix::operator-(Matrix& b){
  Matrix matrixSum(b.getRowSize(),b.getColSize());

  for(int i = 0; i < rowSize; i++){
    for(int j = 0; j < colSize; j++){
      matrixSum.arr[i][j] = arr[i][j] - b.arr[i][j];
    }
  }
  return matrixSum;
}

Matrix Matrix::operator*(Matrix& b){
  if(colSize != b.getRowSize()){
    std::cout << "\nInvalid multiplication, rows and columns must be the same size.\n";
    return b;
  }
  Matrix matrixSum(b);
  matrixSum.scalarMultiply(matrixSum, 0);

  for(long i = 0; i < rowSize; i++){
    for(long j = 0; j < b.getColSize(); j++){
      for(long g = 0; g < b.getRowSize(); g++){
        matrixSum.arr[i][j] += arr[i][g] * b.arr[g][j];
      }
    }
  }
  return matrixSum;
}

void Matrix::scalarMultiply(Matrix& matrix, double m){
  for(int i = 0; i < rowSize; i++){
    for(int j = 0; j < colSize; j++){
      matrix.arr[i][j] = arr[i][j] * m;
    }
  }
}

void Matrix::transposeMatrix(Matrix& matrix){
  Matrix matrixSum(matrix);

  for(int i = 0; i < rowSize; i++){
    for(int j = 0; j < colSize; j++){
      matrixSum.arr[i][j] = matrix.arr[i][j];
    }
  }

  for(int i = 0; i < rowSize; i++){
    for(int j = 0; j < colSize; j++){
      matrix.arr[i][j] = matrixSum.arr[j][i];
    }
  }
}

void Matrix::paddingMatrix(Matrix& matrix){

}

//Symetric and square inversion
Matrix Matrix::inverseSS(Matrix& matrix){
  double det = determinant(matrix);
  Matrix matrixSum(matrix);

  bool needsPadding = false, needsSymetry = false;
  if(rowSize == 1 && colSize == 1){
    return matrix;
  }
  if(rowSize == 2 && colSize == 2){
    det = 1.0/((matrix.arr[0][0]*matrix.arr[1][1])-(matrix.arr[0][1]*matrix.arr[1][0]));
    matrixSum.arr[0][0] = matrix.arr[1][1];
    matrixSum.arr[0][1] = -1*matrix.arr[0][1];
    matrixSum.arr[1][0] = -1*matrix.arr[1][0];
    matrixSum.arr[1][1] = matrix.arr[0][0];
    matrixSum.scalarMultiply(matrixSum,det);
    return matrixSum;
  }
  if(rowSize != colSize){
    std::cout << "\nThe matrix needs to be square!\n";
    return matrix;
  }
  if(matrix.isPowerOfTwo(matrix) == 0){
    needsPadding = true;
    //matrix->addPadding();
  }
  if(matrix.isSymmetric(matrix) == 0){
    needsSymetry = true;
    //matrix = matrix.T() * matrix; //matrix->matrix^T matrix
  }

  return matrix;
}

bool Matrix::isPowerOfTwo(Matrix& matrix){
  int k = matrix.rowSize;

  while(k%2 == 0){
    k = k/2;
    if(k == 0){
      return false;
    }
    if(k == 1){
      return true;
    }
  }

  return false;
}

bool Matrix::isSymmetric(Matrix& matrix){
  Matrix matrixSum(matrix.rowSize,matrix.colSize);
  matrixSum.fillMatrix(0,0,1);

  for(int i = 0; i < rowSize; i++){
    for(int j = 0; j < colSize; j++){
      matrixSum.arr[i][j] = matrix.arr[i][j];
    }
  }
  transposeMatrix(matrixSum);
  for(int i = 0; i < rowSize; i++){
    for(int j = 0; j < colSize; j++){
      if(matrixSum.arr[i][j] != matrix.arr[i][j]){
        return false;
      }
    }
  }
  return true;
}

int Matrix::determinant(Matrix& matrix){
  int sum = 0;
  int sign = 1;
  if(rowSize == 1 && colSize == 1){
    return matrix.arr[0][0];
  }
  if(rowSize == 2 && colSize == 2){
    sum = (matrix.arr[0][0]*matrix.arr[1][1])-(matrix.arr[0][1]*matrix.arr[1][0]);
    return sum;
  }

  for(int i = 0; i < rowSize; i++){
    //sum += sign * matrix.arr[0][i] * determinant(cofactor(matrix));
    sign *= -1;
  }
  return sum;
}

Matrix Matrix::cofactor(Matrix& matrix){
  int cofactor = 0;
  for(int i = 0; i < rowSize; i++){
    for(int j = 0; j < colSize; j++){

    }
  }
  return matrix;
}

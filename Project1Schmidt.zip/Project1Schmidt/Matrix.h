#ifndef MATRIX_H
#define MATRIX_H
#include<iostream>

class Matrix{
private:
  double** arr;
  int rowSize;
  int colSize;

public:
  Matrix(long,long);
  Matrix(const Matrix&);
  Matrix& operator=(const Matrix&);
  ~Matrix();
  long getRowSize();
  void setRowSize(long);
  long getColSize();
  void setColSize(long);
  void printMatrix();
  void fillMatrix(long, long, long);
  void fillMatrixSymmetrically(Matrix&);
  void fillMatrixUser(Matrix&);
  Matrix operator+(Matrix&);
  Matrix operator-(Matrix&);
  Matrix operator*(Matrix&);
  void scalarMultiply(Matrix&, double);
  void transposeMatrix(Matrix&);
  void paddingMatrix(Matrix&);
  Matrix inverseSS(Matrix&);
  bool isPowerOfTwo(Matrix&);
  bool isSymmetric(Matrix&);
  int determinant(Matrix&);
  Matrix cofactor(Matrix&);

};
#endif

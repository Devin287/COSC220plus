#include <iostream>
#include "Matrix.h"
/*
 *Devin Schmidt
 *COSC-320
 *Lab-4
 */
int main(){

  std::cout << "\nTesting Matrix constructor..\n";
  Matrix matrix(3,3);
  matrix.fillMatrix(0,0,1);
  matrix.fillMatrix(1,0,1);
  matrix.printMatrix();

  std::cout << "\nTesting Matrix copy constructor..\n";
  Matrix copyMatrix(matrix);
  copyMatrix.printMatrix();

  std::cout << "\nTesting copy assignment operator..\n";
  Matrix assignmentMatrix = matrix;
  assignmentMatrix.printMatrix();

  std::cout << "\nTesting overloaded multiplication operator..\n";
  copyMatrix.printMatrix();
  std::cout << "   *  \n";
  assignmentMatrix.printMatrix();
  Matrix matrix2 = copyMatrix * assignmentMatrix;
  matrix2.printMatrix();

  std::cout << "\nTesting overloaded addition operator..\n";
  matrix2 = copyMatrix + assignmentMatrix;
  matrix2.printMatrix();

  std::cout << "\nTesting overloaded subtraction operator..\n";
  matrix2 = copyMatrix - assignmentMatrix;
  matrix2.printMatrix();

  std::cout << "\nTesting scalar multiplication..\n";
  matrix2 = matrix2 + assignmentMatrix;
  matrix2.scalarMultiply(matrix2, .2);
  matrix2.printMatrix();

  std::cout << "\nTesting transpose of matrix..\n";
  assignmentMatrix.fillMatrix(0,0,1);
  assignmentMatrix.printMatrix();
  std::cout << "\n";
  assignmentMatrix.transposeMatrix(assignmentMatrix);
  assignmentMatrix.printMatrix();

  std::cout << "\nTesting if a matrix is symmetric in a false case..\n";
  assignmentMatrix.printMatrix();
  if(assignmentMatrix.isSymmetric(assignmentMatrix) == 0){
      std::cout << "Matrix is not symmetric.\n";
  }

  std::cout << "\nTesting if matrix is symmetric in true case..\n";
  matrix.fillMatrixSymmetrically(matrix);
  matrix.printMatrix();
  if(matrix.isSymmetric(matrix) == 1){
      std::cout << "Matrix is symmetric.\n";
  }

  std::cout << "\nTesting determinant..\n";
  matrix.printMatrix();
  int det = matrix.determinant(matrix);
  std::cout << "The determinant is " << det << ".\n";

  std::cout << "\nTesting 2x2 inverse..\n";
  Matrix matrix2By2Inv(2,2);
  matrix2By2Inv.fillMatrix(0,0,1);
  matrix2By2Inv.printMatrix();

  std::cout << "\n";

  matrix2By2Inv = matrix2By2Inv.inverseSS(matrix2By2Inv);
  matrix2By2Inv.printMatrix();
  Matrix matrix2By2(2,2);
  matrix2By2.fillMatrix(0,0,1);

  std::cout << "\nTesting to get the Identity matrix..";
  matrix2By2 = matrix2By2 * matrix2By2Inv;
  std::cout << "\n";
  matrix2By2.printMatrix();

  std::cout << "\n";

  return 0;
}
